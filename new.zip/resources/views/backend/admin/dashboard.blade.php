@extends('backend.layouts.app')
@section('title', 'Admin-Dashboard')
@section('content')


<div class="card">
    <div class="card-body">
        <h3 class="mb-2">Welcome to Dashboard</h3>
        <a href="{{ url('/') }}/admin/logout" class="btn btn-secondary">Logout</a>
    </div>
</div>

@endsection
