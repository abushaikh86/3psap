<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">

<head>
  <title>@yield('title')</title>
  @include('backend.includes.head')
  <link rel="stylesheet" href="{{ asset('public/backend-assets/login.css') }}">
</head>

    <body>

        @yield('content')


        @yield('scripts')
</body>

</html>
