@extends('backend.layouts.app')
@section('title', 'Edit Product')

@section('content')
@php
$status = ['No' => 'No', 'Yes' => 'Yes'];
$product_types = ['simple' => 'Simple', 'configurable' => 'Configurable'];

@endphp
<style>
    .select2-container {
        display: block;
        width: 100% !important;
    }

</style>
<div class="content-header row">
    <div class="content-header-left col-md-6 col-12 mb-2">
        <h3 class="content-header-title">Products</h3>
        <div class="row breadcrumbs-top">
            <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="{{ route('admin.products') }}">Products</a>
                    </li>
                    <li class="breadcrumb-item active">Edit Product</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="content-header-right col-md-6 col-12 mb-md-0 mb-2">
        <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">
            <div class="btn-group" role="group">
                <a class="btn btn-outline-primary" href="{{ route('admin.products') }}">
                    <i class="feather icon-arrow-left"></i> Back
                </a>
            </div>
        </div>
    </div>
</div>
<section id="multiple-column-form">
    <div class="row match-height">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Edit Product</h4>
                </div>
                {{-- {{dd($products)}} --}}
                <div class="card-content">
                    <div class="card-body">
                        @include('backend.includes.errors')
                        {!! Form::model($products, [
                        'method' => 'POST',
                        'url' => ['admin/products/update'],
                        'class' => 'form',
                        'enctype' => 'multipart/form-data',
                        ]) !!}
                        {{ Form::hidden('product_item_id', null, ['required' => true, 'id' => 'product_item_id']) }}
                        <div class="form-body">
                            <!-- <h2>General</h2> -->
                            <div class="row">
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('item_type_id', 'Type ', ['class' => '']) }}
                                        {{ Form::select('item_type_id', $item_types, null, ['class' => 'select2 form-control ', 'placeholder' => 'Please Select Type', 'id' => 'item_type_id']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('item_code', 'Item Code ') }}
                                        {{ Form::text('item_code', null, ['class' => 'form-control', 'placeholder' => 'Enter Item Code', 'required' => true, 'id' => 'item_code']) }}
                                    </div>
                                </div>
                                <div class="col-md-12 col-12">
                                    <div class="form-group">
                                        {{ Form::label('consumer_desc', 'Consumer Description (Product Name)') }}
                                        {{ Form::textarea('consumer_desc', null, ['class' => 'form-control', 'placeholder' => 'Enter Consumer Description', 'id' => 'consumer_desc']) }}
                                    </div>
                                </div>
                                <div class="col-md-12 col-12">
                                    <div class="form-group">
                                        {{ Form::label('product_desc', 'Product Description ') }}
                                        {{ Form::textarea('product_desc', null, ['class' => 'form-control', 'placeholder' => 'Enter Product Description', 'id' => 'product_desc']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('brand_id', 'Brand ', ['class' => '']) }}
                                        {{ Form::select('brand_id', $brands, null, ['class' => 'select2 form-control ', 'placeholder' => 'Please Select Brand', 'id' => 'brand_id']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('category_id', 'Category ', ['class' => '']) }}
                                        {{ Form::select('category_id', $categories, null, ['class' => 'select2 form-control category', 'placeholder' => 'Please Select Category', 'id' => 'product_category_id']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('sub_category_id', 'Sub Category ', ['class' => '']) }}
                                        {{ Form::select('sub_category_id', $sub_categories, null, ['class' => 'select2 form-control subcategory', 'placeholder' => 'Please Select Sub Category']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('variant', 'Variant ') }}
                                        {{ Form::text('variant', null, ['class' => 'form-control', 'placeholder' => 'Enter Variant', 'id' => 'variant']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('buom_pack_size', 'BUoM/ Pack Size ') }}
                                        {{ Form::text('buom_pack_size', null, ['class' => 'form-control', 'placeholder' => 'Enter BUoM/ Pack Size', 'id' => 'buom_pack_size']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('uom_id', 'UoM ', ['class' => '']) }}
                                        {{ Form::select('uom_id', $uoms, null, ['class' => 'select2 form-control uom_id uom_list', 'placeholder' => 'Please Select UoM']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('unit_case', 'Units/ Case Or Case Config ') }}
                                        {{ Form::text('unit_case', null, ['class' => 'form-control', 'placeholder' => 'Enter Units/ Case Or Case Config', 'id' => 'unit_case']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('hsncode_id', 'HSN Code ', ['class' => '']) }}
                                        {{ Form::select('hsncode_id', $hsncodes, null, ['class' => 'select2 form-control hsncode_id', 'placeholder' => 'Please Select HSN Code']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('batch', 'Batch ') }}
                                        {{ Form::text('batch', null, ['class' => 'form-control', 'placeholder' => 'Enter Batch', 'id' => 'batch']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('expiry_date', 'Expiry Date ') }}
                                        {{ Form::date('expiry_date', null, ['class' => 'form-control pickadate', 'placeholder' => 'Enter Expiry Date', 'id' => 'expiry_date']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('shelf_life', 'Shelf Life ', ['class' => '']) }}
                                        {{ Form::select('shelf_life', ['month' => 'Month', 'days' => 'Days'], null, ['class' => 'select2 form-control ', 'id' => 'shelf_life']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('sourcing', 'Sourcing Unit/ Source ') }}
                                        {{ Form::text('sourcing', null, ['class' => 'form-control', 'placeholder' => 'Enter Sourcing Unit/ Source', 'required' => true, 'id' => 'sourcing']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('case_pallet', 'Case/ Pallet ') }}
                                        {{ Form::text('case_pallet', null, ['class' => 'form-control', 'placeholder' => 'Enter Case/ Pallet', 'id' => 'case_pallet']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('layer_pallet', 'Layer/ Pallet ') }}
                                        {{ Form::text('layer_pallet', null, ['class' => 'form-control', 'placeholder' => 'Enter Layer/ Pallet', 'id' => 'layer_pallet']) }}
                                    </div>
                                </div>
                                <div class="col-md-4 col-12" id="">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_unit_pack', 'Unit/ Pack ') }}
                                        {{ Form::text('dimensions_unit_pack', null, ['class' => 'form-control', 'placeholder' => 'Enter Unit/ Pack']) }}
                                    </div>
                                </div>
                                <div class="col-md-2 col-12">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_length', 'Case Length ') }}
                                        {{ Form::text('dimensions_length', null, ['class' => 'form-control', 'placeholder' => 'Enter Length']) }}
                                    </div>
                                </div>
                                <div class="col-md-2 col-12">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_width', 'Case Width') }}
                                        {{ Form::text('dimensions_width', null, ['class' => 'form-control', 'placeholder' => 'Enter Width']) }}
                                    </div>
                                </div>
                                <div class="col-md-2 col-12">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_height', 'Case Height') }}
                                        {{ Form::text('dimensions_height', null, ['class' => 'form-control', 'placeholder' => 'Enter Height']) }}
                                    </div>
                                </div>
                                <div class="col-md-2 col-12">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_length_uom_id', 'UoM ', ['class' => '']) }}
                                        {{ Form::select('dimensions_length_uom_id', $uoms, null, ['class' => 'select2 form-control dimensions_length_uom_id uom_list', 'placeholder' => 'Please Select UoM']) }}
                                    </div>
                                </div>
                                <!-- <div class="col-md-2 col-12">
                                        <div class="form-group">
                                          {{ Form::label('dimensions_width_uom_id', 'UoM ', ['class' => '']) }}
                                          {{ Form::select('dimensions_width_uom_id', $uoms, null, ['class' => 'select2 form-control dimensions_width_uom_id uom_list', 'placeholder' => 'Please Select UoM']) }}
                                        </div>
                                      </div> -->
                                <!-- <div class="col-md-2 col-12">
                                        <div class="form-group">
                                          {{ Form::label('dimensions_height_uom_id', 'UoM ', ['class' => '']) }}
                                          {{ Form::select('dimensions_height_uom_id', $uoms, null, ['class' => 'select2 form-control dimensions_height_uom_id uom_list', 'placeholder' => 'Please Select UoM']) }}
                                        </div>
                                      </div> -->
                                <div class="col-md-2 col-12">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_net_weight', 'Net Weight') }}
                                        {{ Form::text('dimensions_net_weight', null, ['class' => 'form-control', 'placeholder' => 'Enter Net Weight']) }}
                                    </div>
                                </div>
                                <div class="col-md-2 col-12">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_gross_weight', 'Gross Weight') }}
                                        {{ Form::text('dimensions_gross_weight', null, ['class' => 'form-control', 'placeholder' => 'Enter Gross Weight']) }}
                                    </div>
                                </div>
                                <div class="col-md-2 col-12">
                                    <div class="form-group">
                                        {{ Form::label('dimensions_net_uom_id', 'UoM ', ['class' => '']) }}
                                        {{ Form::select('dimensions_net_uom_id', $uoms, null, ['class' => 'select2 form-control dimensions_net_uom_id uom_list', 'placeholder' => 'Please Select UoM']) }}
                                    </div>
                                </div>
                                <!-- <div class="col-md-2 col-12">
                                        <div class="form-group">
                                          {{ Form::label('dimensions_gross_weight_uom_id', 'UoM ', ['class' => '']) }}
                                          {{ Form::select('dimensions_gross_weight_uom_id', $uoms, null, ['class' => 'select2 form-control dimensions_gross_weight_uom_id uom_list', 'placeholder' => 'Please Select UoM']) }}
                                        </div>
                                      </div> -->
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        {{ Form::label('ean_barcode', 'EAN/ Barcode') }}
                                        {{ Form::text('ean_barcode', null, ['class' => 'form-control', 'placeholder' => 'Enter EAN/ Barcode']) }}
                                    </div>
                                </div>
                                <div class="col-md-3 col-12">
                                    <div class="form-group">
                                        {{ Form::label('mrp', 'MRP') }}
                                        {{ Form::text('mrp', null, ['class' => 'form-control', 'placeholder' => 'Enter MRP']) }}
                                    </div>
                                </div>

                                <div class="col-md-3 col-12">
                                    <div class="form-group">
                                        {{ Form::label('gst_id', 'GST (%)', ['class' => '']) }}
                                        {{ Form::select('gst_id', $gst, null, ['class' => 'form-control', 'placeholder' => 'Please Select GST']) }}
                                    </div>
                                </div>
                                <div class="col-md-6 col-6">
                                    {{ Form::label('visibility', 'Show / Hide') }}
                                    <fieldset class="">
                                        <div class="radio radio-success">
                                            {{ Form::radio('visibility', '1', true, ['id' => 'radioshow']) }}
                                            {{ Form::label('radioshow', 'Yes') }}
                                        </div>
                                        <!-- </fieldset>
                                        <fieldset> -->
                                        <div class="radio radio-danger">
                                            {{ Form::radio('visibility', '0', false, ['id' => 'radiohide']) }}
                                            {{ Form::label('radiohide', 'No') }}
                                        </div>
                                    </fieldset>
                                </div>
                                {{-- Repeater code  --}}
                                <div class='col-md-12 col-12'>
                                    {{ Form::label('table', 'Inventory') }}
                                    <table class='table borderd'>
                                        <tr>
                                            <th>Sr. No</th>
                                            <th>Storage Location</th>
                                            <th>Quantity</th>
                                        </tr>
                                        <tbody>
                                            @if (isset($qty_location) && count($qty_location) > 0)
                                            @foreach ($qty_location as $qty)
                                            <tr>
                                                <td>
                                                    {{ $loop->index+1 }}
                                                </td>

                                                <td>
                                                    {{ Form::select('storage_location_id[]', $storage_locations, $qty->storage_location_id, ['class' => 'select2 form-control w-100', 'placeholder' => 'Please Select Storage Location']) }}
                                                </td>

                                                <td>
                                                    {{ Form::text('qty[]', $qty->qty, ['class' => 'form-control ', 'placeholder' => 'Please Enter Quantity']) }}
                                                </td>

                                            </tr>
                                            @endforeach

                                            @else
                                            <tr>
                                                <td>
                                                    1
                                                </td>

                                                <td>
                                                    {{ Form::select('storage_location_id[]', $storage_locations, null, ['class' => 'select2 form-control w-100', 'placeholder' => 'Please Select Storage Location']) }}
                                                </td>

                                                <td>
                                                    {{ Form::text('qty[]', null, ['class' => 'form-control ', 'placeholder' => 'Please Enter Quantity']) }}
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    2
                                                </td>

                                                <td>
                                                    {{ Form::select('storage_location_id[]', $storage_locations, null, ['class' => 'select2 form-control w-100', 'placeholder' => 'Please Select Storage Location']) }}
                                                </td>

                                                <td>
                                                    {{ Form::text('qty[]', null, ['class' => 'form-control ', 'placeholder' => 'Please Enter Quantity']) }}
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    3
                                                </td>

                                                <td>
                                                    {{ Form::select('storage_location_id[]', $storage_locations, null, ['class' => 'select2 form-control w-100', 'placeholder' => 'Please Select Storage Location']) }}
                                                </td>

                                                <td>
                                                    {{ Form::text('qty[]', null, ['class' => 'form-control ', 'placeholder' => 'Please Enter Quantity']) }}
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    4
                                                </td>

                                                <td>
                                                    {{ Form::select('storage_location_id[]', $storage_locations, null, ['class' => 'select2 form-control w-100', 'placeholder' => 'Please Select Storage Location']) }}
                                                </td>

                                                <td>
                                                    {{ Form::text('qty[]', null, ['class' => 'form-control ', 'placeholder' => 'Please Enter Quantity']) }}
                                                </td>
                                            </tr>
                                            @endif
                                        </tbody>
                                    </table>

                                    {{-- @if (isset($qty_location) && count($qty_location) > 0)  --}}
                                    {{-- @foreach ($qty_location as $qty)
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    {{ Form::label('qty', 'Quantity ', ['class' => '']) }}
                                    {{ Form::text('qty[]', $qty->qty, ['class' => 'form-control', 'placeholder' => 'Please Enter Quantity']) }}
                                </div>
                            </div>

                            <div class="col-md-6 col-12">
                                <div class="form-group">
                                    {{ Form::label('storage_location_id', 'Storage Location 1', ['class' => '']) }}
                                    {{ Form::select('storage_location_id[]', $storage_locations, $qty->storage_location_id, ['class' => 'select2 form-control', 'placeholder' => 'Please Select Storage Location']) }}
                                </div>
                            </div>
                            @endforeach --}}
                            {{-- @else
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                {{ Form::label('qty', 'Quantity ', ['class' => '']) }}
                            {{ Form::text('qty[]', null, ['class' => 'form-control', 'placeholder' => 'Please Enter Quantity']) }}
                        </div>
                    </div>

                    <div class="col-md-6 col-12">
                        <div class="form-group">
                            {{ Form::label('storage_location_id', 'Storage Location 1', ['class' => '']) }}
                            {{ Form::select('storage_location_id[]', $storage_locations, null, ['class' => 'select2 form-control', 'placeholder' => 'Please Select Storage Location']) }}
                        </div>
                    </div>
                    @endif --}}
                </div>
                {{-- Repeater code end  --}}
                <div class="col-md-12 col-12">
                    <div class="form-group">
                        {{ Form::label('product_thumb', 'Product Thumbnail *') }}
                        <div class="custom-file">
                            {{ Form::file('product_thumb', ['class' => 'custom-file-input', 'id' => 'product_thumb']) }}
                            <label class="custom-file-label" for="product_thumb">Choose
                                file</label>
                        </div>
                    </div>
                </div>
                <div class="col-12 d-flex justify-content-start">
                    {{ Form::submit('Update', ['class' => 'btn btn-primary mr-1 mb-1']) }}
                </div>
            </div>
        </div>
        {{ Form::close() }}

    </div>

    </div>
    </div>
    </div>
    </div>
</section>
</div>
</div>
<div class="modal fade text-left" id="image_delete_toast" tabindex="-1" role="dialog" aria-labelledby="myModalLabel120" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h5 class="modal-title white" id="myModalLabel120">Warning</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="bx bx-x"></i>
                </button>
            </div>
            <div class="modal-body" id="delete_image_toast_content">
                Please Select Product Images To Delete.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
            </div>
        </div>
    </div>
</div>
<!-- brands modal -->
<div class="modal fade text-left" id="add_brand_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Add Brand</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                @include('backend.brands._form')
            </div>
            <!-- <div class="modal-footer">
                              <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Close</button>
                              <button type="button" class="btn btn-outline-primary">Save changes</button>
                          </div> -->
        </div>
    </div>
</div>
<!-- uoms modal -->
<div class="modal fade text-left" id="add_uom_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Add Brand</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                @include('backend.uoms._form')
            </div>
        </div>
    </div>
</div>
<!-- hsncodes modal -->
<div class="modal fade text-left" id="add_hsncode_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Add Brand</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                @include('backend.hsncodes._form')
            </div>
        </div>
    </div>
</div>
<div class="modal fade text-left" id="add_category_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Add Category</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                @include('backend.categories._form')
            </div>
        </div>
    </div>
</div>
<div class="modal fade text-left" id="add_sub_category_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Add Sub Category</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                @include('backend.subcategories._form', compact('categories'))
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        if ($(".category").val() != '') {
            subcategories($(".category").val());
        }
        $(".category").change(function() {
            var category_id = $(this).val();
            subcategories(category_id);
        });

        function subcategories(category_id) {
            $.ajax({
                url: '{{ url('
                admin / products / getsubcategory ') }}'
                , type: 'post'
                , data: {
                    category_id: category_id
                    , _token: "{{ csrf_token() }}"
                , }
                , success: function(data) {
                    //console.log(data);
                    $('.subcategory').html(data);
                    $('.subsubcategory').html('');
                    // $('.hsncode_id').html('');
                }
            });
        }
        $(document).on('click', '#open_brand_modal', function() {
            console.log('test in brand');
            $('#brand_id').select2('close');
            $('#add_brand_modal').modal('show');
        });
        $('#submit_brand').on('click', function() {
            var brand_name = $("#brand_name", $('#add_brand_modal')).val();
            var brand_desc = $("#brand_desc", $('#add_brand_modal')).val();
            if (brand_name != '') {
                console.log('in');
                $.ajax({
                    url: '{{ url('
                    admin / brands / store ') }}'
                    , type: 'post'
                    , data: {
                        brand_name: brand_name
                        , brand_desc: brand_desc
                        , _token: "{{ csrf_token() }}"
                        , form_type: 'brand_modal'
                    , }
                    , dataType: 'json'
                    , success: function(data) {
                        // console.log(data['brands']);
                        if (data.flag == 'success') {
                            alert(data['message']);
                            $("#brand_id").html(data['brands']);
                            $('#add_brand_modal').modal('hide');
                            // $('#delete_image_toast_content').text('Images Deleted Successfully');
                            // $('#image_delete_toast').modal('show');
                        } else {
                            alert(data['message']);
                            // console.log(data);
                            $('#add_brand_modal').modal('hide');
                            // $('#delete_image_toast_content').text('Something went wrong!');
                            // $('#image_delete_toast').modal('show');

                        }
                    }
                });
                // $('#add_brand_modal').modal('show');
            }
        });
        $('.select2').select2();
        var branddropdowncnt = 1;
        $('#brand_id').on('select2:open', function() {
            let brand_options = $(this).data('select2');
            if (!$('.select2-link').length) {
                if (branddropdowncnt == 1) {
                    brand_options.$results.parents('.select2-results')
                        .append(
                            '<div class="select2-link2 select2-close text-right"><button id="open_brand_modal" class="btn btn-secondary">Add New Item +</button></div>'
                        )
                        .on('click', function(b) {
                            // $('#add_brand_modal').modal('show');
                        });
                    branddropdowncnt++;
                }
            }
        });
        var catdropdowncnt = 1;
        $('#product_category_id').on('select2:open', function() {
            let category_options = $(this).data('select2');
            if (!$('.select2-link').length) {
                if (catdropdowncnt == 1) {
                    category_options.$results.parents('.select2-results')
                        .append(
                            '<div class="select2-link2 select2-close text-right"><button id="open_category_modal" class="btn btn-secondary">Add New Item +</button></div>'
                        )
                        .on('click', function(b) {
                            // $('#add_brand_modal').modal('show');
                        });
                    catdropdowncnt++;
                }
            }
        });
        $(document).on('click', '#open_category_modal', function() {
            console.log('test in category');
            $('#product_category_id').select2('close');
            $('#add_category_modal').modal('show');
        });
        $('#submit_category').on('click', function() {
            var category_name = $("#category_name", $('#add_category_modal')).val();
            var category_description = $("#category_description", $('#add_category_modal')).val();
            var has_subcategories = $("input[name=has_subcategories]:checked", $('#add_category_modal'))
                .val();
            var visibility = $("input[name=visibility]:checked", $('#add_category_modal')).val();
            if (category_name != '' && category_description != '') {
                console.log('in');
                $.ajax({
                    url: '{{ url('
                    admin / categories / store ') }}'
                    , type: 'post'
                    , data: {
                        category_name: category_name
                        , category_description: category_description
                        , has_subcategories: has_subcategories
                        , visibility: visibility
                        , _token: "{{ csrf_token() }}"
                        , form_type: 'category_modal'
                    , }
                    , dataType: 'json'
                    , success: function(data) {
                        // console.log(data['brands']);
                        if (data.flag == 'success') {
                            alert(data['message']);
                            $("#product_category_id").html(data['categories']);
                            $('#add_category_modal').modal('hide');
                        } else {
                            alert(data['message']);
                            // console.log(data);
                            $('#add_category_modal').modal('hide');

                        }
                    }
                });
                // $('#add_brand_modal').modal('show');
            }
        });
        var subcatdropdowncnt = 1;
        $('#sub_category_id').on('select2:open', function() {
            let sub_category_options = $(this).data('select2');
            if (!$('.select2-link').length) {
                if (subcatdropdowncnt == 1) {
                    sub_category_options.$results.parents('.select2-results')
                        .append(
                            '<div class="select2-link2 select2-close text-right"><button id="open_sub_category_modal" class="btn btn-secondary">Add New Item +</button></div>'
                        )
                        .on('click', function(b) {
                            // $('#add_brand_modal').modal('show');
                        });
                    subcatdropdowncnt++;
                }
            }
        });
        $(document).on('click', '#open_sub_category_modal', function() {
            console.log('test in sub category');
            $('#sub_category_id').select2('close');
            $('#add_sub_category_modal').modal('show');
        });
        $('#submit_sub_category').on('click', function() {
            // console.log($(this));
            // console.log($(this).siblings);
            // var category_id = $("#add_sub_category_modal").children().children().children().children().children().children().find("#category_id").val();
            var category_id = $("#category_id", $('#add_sub_category_modal')).val();
            var selection_category_id = $("#product_category_id").val();
            // var subcategory_name = $("#add_sub_category_modal").children().children().children().children().children().children().find("#subcategory_name").val();
            var subcategory_name = $("#subcategory_name", $('#add_sub_category_modal')).val();
            // var subcategory_description = $("#add_sub_category_modal").children().children().children().children().children().children().find("#subcategory_description").val();
            var subcategory_description = $("#subcategory_description", $('#add_sub_category_modal'))
                .val();
            // var visibility = $("#add_sub_category_modal").children().children().children().children().children().children().find("input[name=visibility]:checked").val();
            var visibility = $("#visibility", $('#add_sub_category_modal')).val();
            if (subcategory_name != '' && subcategory_description != '') {
                console.log('in');
                $.ajax({
                    url: '{{ url('
                    admin / subcategories / store ') }}'
                    , type: 'post'
                    , data: {
                        subcategory_name: subcategory_name
                        , subcategory_description: subcategory_description
                        , visibility: visibility
                        , category_id: category_id
                        , _token: "{{ csrf_token() }}"
                        , form_type: 'sub_category_modal'
                        , selection_category_id: selection_category_id
                    , }
                    , dataType: 'json'
                    , success: function(data) {
                        // console.log(data['brands']);
                        if (data.flag == 'success') {
                            alert(data['message']);
                            $("#sub_category_id").html(data['sub_categories']);
                            $('#add_sub_category_modal').modal('hide');
                        } else {
                            alert(data['message']);
                            // console.log(data);
                            $('#add_sub_category_modal').modal('hide');

                        }
                    }
                });
                // $('#add_brand_modal').modal('show');
            }
        });
        //$(".select2-results:not(:has(a))")
        // $("#brand_id").append('<option value="add_brand"><a href="#" style="padding: 6px;height: 20px;display: inline-table;">Create new item</a></option>');
        $(document).on('click', '#open_uom_modal', function() {
            console.log('test in uom');
            $('#uom_id').select2('close');
            $('#add_uom_modal').modal('show');
        });
        $('#submit_uom').on('click', function() {
            var uom_name = $("#uom_name", $('#add_uom_modal')).val();
            var uom_desc = $("#uom_desc", $('#add_uom_modal')).val();
            if (uom_name != '') {
                console.log('in');
                $.ajax({
                    url: '{{ url('
                    admin / uoms / store ') }}'
                    , type: 'post'
                    , data: {
                        uom_name: uom_name
                        , uom_desc: uom_desc
                        , _token: "{{ csrf_token() }}"
                        , form_type: 'uom_modal'
                    , }
                    , dataType: 'json'
                    , success: function(data) {
                        // console.log(data['uoms']);
                        if (data.flag == 'success') {
                            alert(data['message']);
                            $(".uom_list").html(data['uoms']);
                            $('#add_uom_modal').modal('hide');
                            // $('#delete_image_toast_content').text('Images Deleted Successfully');
                            // $('#image_delete_toast').modal('show');
                        } else {
                            alert(data['message']);
                            // console.log(data);
                            $('#add_uom_modal').modal('hide');
                            // $('#delete_image_toast_content').text('Something went wrong!');
                            // $('#image_delete_toast').modal('show');

                        }
                    }
                });
                // $('#add_uom_modal').modal('show');
            }
        });
        var uomdropdowncnt = 1;
        $('#uom_id').on('select2:open', function() {
            let uom_options = $(this).data('select2');
            if (!$('.select2-link').length) {
                if (uomdropdowncnt == 1) {
                    uom_options.$results.parents('.select2-results')
                        .append(
                            '<div class="select2-link2 select2-close text-right"><button id="open_uom_modal" class="btn btn-secondary">Add New Item +</button></div>'
                        )
                        .on('click', function(b) {
                            // $('#add_uom_modal').modal('show');
                        });
                    uomdropdowncnt++;
                }
            }
        });
        $(document).on('click', '#open_hsncode_modal', function() {
            console.log('test in hsncode');
            $('#hsncode_id').select2('close');
            $('#add_hsncode_modal').modal('show');
        });
        $('#submit_hsncode').on('click', function() {
            var hsncode_name = $("#hsncode_name", $('#add_hsncode_modal')).val();
            var hsncode_desc = $("#hsncode_desc", $('#add_hsncode_modal')).val();
            if (hsncode_name != '') {
                console.log('in');
                $.ajax({
                    url: '{{ url('
                    admin / hsncodes / store ') }}'
                    , type: 'post'
                    , data: {
                        hsncode_name: hsncode_name
                        , hsncode_desc: hsncode_desc
                        , _token: "{{ csrf_token() }}"
                        , form_type: 'hsncode_modal'
                    , }
                    , dataType: 'json'
                    , success: function(data) {
                        // console.log(data['hsncodes']);
                        if (data.flag == 'success') {
                            alert(data['message']);
                            $("#hsncode_id").html(data['hsncodes']);
                            $('#add_hsncode_modal').modal('hide');
                            // $('#delete_image_toast_content').text('Images Deleted Successfully');
                            // $('#image_delete_toast').modal('show');
                        } else {
                            alert(data['message']);
                            // console.log(data);
                            $('#add_hsncode_modal').modal('hide');
                            // $('#delete_image_toast_content').text('Something went wrong!');
                            // $('#image_delete_toast').modal('show');

                        }
                    }
                });
                // $('#add_hsncode_modal').modal('show');
            }
        });
        var hsncodedropdowncnt = 1;
        $('#hsncode_id').on('select2:open', function() {
            let hsncode_options = $(this).data('select2');
            if (!$('.select2-link').length) {
                if (hsncodedropdowncnt == 1) {
                    hsncode_options.$results.parents('.select2-results')
                        .append(
                            '<div class="select2-link2 select2-close text-right"><button id="open_hsncode_modal" class="btn btn-secondary">Add New Item +</button></div>'
                        )
                        .on('click', function(b) {
                            // $('#add_hsncode_modal').modal('show');
                        });
                    hsncodedropdowncnt++;
                }
            }
        });
    });

</script>
@endsection
