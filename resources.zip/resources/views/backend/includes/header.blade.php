@php
$user_id = Auth()->guard('admin')->user()->id;
$user = Auth()->guard('admin')->user();
@endphp


<!-- BEGIN: Header-->
<nav class="header-navbar navbar-expand-md navbar-dark navbar-with-menu navbar-static-top navbar-light navbar-border navbar-brand-center">
  <div class="navbar-wrapper">
    <div class="navbar-header">
      <ul class="nav navbar-nav flex-row">
        <li class="nav-item mobile-menu d-lg-none mr-auto">
          <a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#">
            <i class="feather icon-menu font-large-1"></i>
          </a>
        </li>
        <li class="nav-item mr-auto">
          <a class="navbar-brand" href="{{ route('admin.dashboard') }}">
            <img class="brand-logo" alt="logo" src="{{ asset('public/backend-assets/images/logo-demo.png') }}">
            <h2 class="brand-text">3PSAP</h2>
          </a>
        </li>
        <li class="nav-item d-none d-lg-block nav-toggle">
          <a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse">
            <i class="toggle-icon feather icon-toggle-right font-medium-3 white" data-ticon="feather.icon-toggle-right"></i>
          </a>
        </li>
        <li class="nav-item d-lg-none">
          <a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile">
            <i class="fa fa-ellipsis-v"></i>
          </a>
        </li>
      </ul>
    </div>
    <div class="navbar-container content">
      <div class="collapse navbar-collapse" id="navbar-mobile">
        <div class="mr-auto"></div>
        <ul class="nav navbar-nav float-right">
          <li class="dropdown dropdown-user nav-item">
            <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
              <div class="avatar avatar-online">
                <img src="{{ asset('public/backend-assets/app-assets/images/demo-avatar.webp') }}" alt="avatar"><i></i>
              </div>
              <span class="user-name">{{ $user->first_name}} {{$user->last_name}}</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <a class="dropdown-item" href="{{ route('admin.profile') }}">
                <i class="feather icon-user"></i> Edit Profile
              </a>
              <a class="dropdown-item" href="{{ route('admin.change_password') }}">
                <i class="feather icon-check-square"></i> Change Password
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="{{ route('admin.logout') }}">
                <i class="feather icon-power"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>
<!-- END: Header-->