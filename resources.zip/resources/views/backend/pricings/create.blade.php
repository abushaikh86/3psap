@extends('backend.layouts.app')
@section('title', 'Create Pricing')

@section('content')
@php

@endphp
<div class="content-header row">
  <div class="content-header-left col-md-6 col-12 mb-2">
    <h3 class="content-header-title">Pricings</h3>
    <div class="row breadcrumbs-top">
      <div class="breadcrumb-wrapper col-12">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{ route('admin.dashboard')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item">
            <a href="{{ route('admin.pricings')}}">Pricings</a>
          </li>
          <li class="breadcrumb-item active">Add Pricing</li>
        </ol>
      </div>
    </div>
  </div>
  <div class="content-header-right col-md-6 col-12 mb-md-0 mb-2">
    <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">
      <div class="btn-group" role="group">
        <a class="btn btn-outline-primary" href="{{ route('admin.pricings') }}">
          <i class="feather icon-arrow-left"></i> Back
        </a>
      </div>
    </div>
  </div>
</div>
        <section id="multiple-column-form">
          <div class="row match-height">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Create Pricing</h4>
                </div>
                <div class="card-content">
                  <div class="card-body">
                    @include('backend.includes.errors')
                    {{ Form::open(array('url' => 'admin/pricings/store','enctype' => 'multipart/form-data')) }}
                      <div class="form-body">
                        <div class="row">
                          <div class="col-md-6 col-12">
                            <div class="form-group">
                              {{ Form::label('sku_code', 'SKU Code ',['class'=>'']) }}
                              {{ Form::select('sku_code', $products , null,['class'=>'select2 form-control ', 'placeholder' => 'Please Select SKU Code','id'=>'sku_code']) }}
                            </div>
                          </div>
                          <div class="col-md-6 col-12">
                            <div class="form-group">
                              {{ Form::label('sku_description', 'SKU Description ') }}
                              {{ Form::text('sku_description', null, ['class' => 'form-control', 'placeholder' => 'Enter SKU Description', 'required' => true,'id'=>'sku_description']) }}
                            </div>
                          </div>
                          <div class="col-md-6 col-12">
                            <div class="form-group">
                              {{ Form::label('hsn_code_id', 'HSN Code ',['class'=>'']) }}
                              {{ Form::select('hsn_code_id', $hsncodes , null,['class'=>'select2 form-control hsncode_id', 'placeholder' => 'Please Select HSN Code']) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('basic_purchase_price_cp', 'Basic Purchase Price/ CP') }}
                              {{ Form::text('basic_purchase_price_cp', null, ['class' => 'form-control', 'placeholder' => 'Enter Basic Purchase Price/ CP', 'id'=>'basic_purchase_price_cp']) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('tax_1', 'Tax 1 ') }}
                              {{ Form::text('tax_1', null, ['class' => 'form-control', 'placeholder' => 'Enter Tax 1','id'=>'tax_1', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('tax_2', 'Tax 2 ') }}
                              {{ Form::text('tax_2', null, ['class' => 'form-control ', 'placeholder' => 'Enter Tax 2','id'=>'tax_2', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('gross_pp_cp', 'Gross PP/ CP ') }}
                              {{ Form::text('gross_pp_cp', null, ['class' => 'form-control', 'placeholder' => 'Enter Gross PP/ CP','required' => true,'id'=>'gross_pp_cp', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('import_cost_1', 'Import Cost/ CIF Cost 1 ') }}
                              {{ Form::text('import_cost_1', null, ['class' => 'form-control', 'placeholder' => 'Enter Import Cost/ CIF Cost 1','required' => true,'id'=>'import_cost_1', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('import_cost_2', 'Import Cost/ CIF Cost 2 ') }}
                              {{ Form::text('import_cost_2', null, ['class' => 'form-control', 'placeholder' => 'Enter Import Cost/ CIF Cost 2','required' => true,'id'=>'import_cost_2', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('port_clearance_charges_cost_1', 'Port Clearance Charges Cost 1 ') }}
                              {{ Form::text('port_clearance_charges_cost_1', null, ['class' => 'form-control', 'placeholder' => 'Enter Port Clearance Charges Cost 1','required' => true,'id'=>'port_clearance_charges_cost_1', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('port_clearance_charges_cost_2', 'Port Clearance Charges Cost 2 ') }}
                              {{ Form::text('port_clearance_charges_cost_2', null, ['class' => 'form-control', 'placeholder' => 'Enter Port Clearance Charges Cost 2','required' => true,'id'=>'port_clearance_charges_cost_2', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('local_tpt_storage_cost_1', 'Local Tpt. & Storage Cost 1 ') }}
                              {{ Form::text('local_tpt_storage_cost_1', null, ['class' => 'form-control', 'placeholder' => 'Enter Local Tpt. & Storage Cost 1','required' => true,'id'=>'local_tpt_storage_cost_1', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('local_tpt_storage_cost2', 'Local Tpt. & Storage Cost 2 ') }}
                              {{ Form::text('local_tpt_storage_cost2', null, ['class' => 'form-control', 'placeholder' => 'Enter Local Tpt. & Storage Cost 2','required' => true,'id'=>'local_tpt_storage_cost2', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('landed_product_cost', 'Landed Product Cost ') }}
                              {{ Form::text('landed_product_cost', null, ['class' => 'form-control', 'placeholder' => 'Enter Landed Product Cost','id'=>'landed_product_cost', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('margin_percent', 'Margin % ') }}
                              {{ Form::text('margin_percent', null, ['class' => 'form-control', 'placeholder' => 'Enter Margin %','id'=>'margin_percent', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('margin', 'Margin ') }}
                              {{ Form::text('margin', null, ['class' => 'form-control', 'placeholder' => 'Enter Margin','id'=>'margin', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('sp_excl_gst', 'SP excl. GST ') }}
                              {{ Form::text('sp_excl_gst', null, ['class' => 'form-control', 'placeholder' => 'Enter SP excl. GST', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('gst_percent', 'GST %') }}
                              {{ Form::text('gst_percent', null, ['class' => 'form-control', 'placeholder' => 'Enter GST %', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('gst', 'GST') }}
                              {{ Form::text('gst', null, ['class' => 'form-control', 'placeholder' => 'Enter GST', ]) }}
                            </div>
                          </div>
                          <div class="col-md-3 col-12">
                            <div class="form-group">
                              {{ Form::label('sp_incl_gst', 'SP incl. GST') }}
                              {{ Form::text('sp_incl_gst', null, ['class' => 'form-control', 'placeholder' => 'Enter SP incl. GST', ]) }}
                            </div>
                          </div>
                          
                          
                          <div class="col-md-6 col-6">
                            {{ Form::label('visibility', 'Show / Hide') }}
                            <fieldset class="">
                              <div class="radio radio-success">
                                {{ Form::radio('visibility','1',true,['id'=>'radioshow']) }}
                                {{ Form::label('radioshow', 'Yes') }}
                              </div>
                            <!-- </fieldset>
                            <fieldset> -->
                              <div class="radio radio-danger">
                                {{ Form::radio('visibility','0',false,['id'=>'radiohide']) }}
                                {{ Form::label('radiohide', 'No') }}
                              </div>
                            </fieldset>
                          </div>
                          
                          <div class="col-12 d-flex justify-content-start">
                            {{ Form::submit('Save', array('class' => 'btn btn-primary mr-1 mb-1')) }}
                            <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                          </div>
                        </div>
                      </div>
                    {{ Form::close() }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
    <script>
      $(document).ready(function()
      {
        if ($("#sku_code").val() != '')
        {
          getproductdetails($("#sku_code").val());
        }
        $("#category_id").change(function(){
          var category_id = $(this).val();
          subcategories(category_id);
        });
        function subcategories(category_id)
        {
          $.ajax({
              url: '{{url("admin/pricings/getsubcategory")}}',
              type: 'post',
              data:
              {
                category_id: category_id ,_token: "{{ csrf_token() }}",
              },
              success: function (data)
              {
                //console.log(data);
                $('.subcategory').html(data);
              }
           });
        }
        $("#sku_code").change(function(){
          var sku_code = $(this).val();
          getproductdetails(sku_code);
        });
        function getproductdetails(sku_code)
        {
          $.ajax({
              url: '{{url("admin/pricings/getproductdetails")}}',
              type: 'post',
              data:
              {
                sku_code: sku_code ,_token: "{{ csrf_token() }}",
              },
              success: function (data)
              {
                //console.log(data);
                $('#hsn_code_id').val(data['hsn_code']);
                $('#basic_purchase_price_cp').val(data['mrp']);
              }
           });
        }
   
        
      });
    </script>
@endsection
