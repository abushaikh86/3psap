@extends('backend.layouts.app')
@section('title', 'Business Partner')
@php
    use Spatie\Permission\Models\Role;
@endphp
@section('content')

    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Create Business Partner</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">Create</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-header-right col-md-6 col-12 mb-md-0 mb-2">
            <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">
                <div class="btn-group" role="group">
                    <a class="btn btn-outline-primary" href="{{ route('admin.bussinesspartner') }}">
                        <i class="feather icon-eye"></i> view
                    </a>
                </div>
            </div>
        </div>
    </div>


    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body card-dashboard">
                            @include('backend.includes.errors')
                            {{ Form::open(['url' => 'admin/bussinesspartner/store']) }}
                            @csrf
                            <div class="form-body">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{-- {{ Form::label('Business Partner Type', 'Business Partner Type *') }}
                                            <select name="business_partner_type" id="business_partner_type"
                                                class="form-control" placeholder='Select Bussiness Partner Type' required> 
                                                <option value="">Select Business Partner Type</option>
                                                @foreach ($bussinesstype as $btype)
                                                    <option value="{{ $btype->bussiness_master_type_id }}">
                                                        {{ ucfirst($btype->bussiness_master_type) }}</option>
                                                @endforeach
                                            </select> --}}

                                            {{ Form::label('business_partner_type', 'Business Partner Type *') }}
                                            {{ Form::select('business_partner_type', $bussinesstype, null, ['class' => 'form-control', 'placeholder' => 'Select Business Partner Type', 'required' => true]) }}
                                        </div>
                                    </div>
                                    {{-- <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bp_code', 'Business Partner Code *') }}
                                            {{ Form::text('bp_code', null, ['class' => 'form-control', 'placeholder' => 'Business Partner Code', 'required' => true]) }}
                                        </div>
                                    </div> --}}

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bp_name', 'Business Partner Name *') }}
                                            {{ Form::text('bp_name', null, ['class' => 'form-control', 'placeholder' => 'Business Partner Name', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{-- {{ Form::label('Bussness Partner Type', 'Bussness Partner Organization Type *') }}
                                            <select name="bp_organisation_type" id="bp_organisation_type"
                                                class="form-control" placeholder='Select Business Organization Type' required>
                                                <option value="">Select Business Partner Organization</option>
                                                @foreach ($bpOrgType as $OrgType)
                                                    <option value="{{ $OrgType->bp_organisation_type_id }}">
                                                        {{ $OrgType->bp_organisation_type }}</option>
                                                @endforeach

                                            </select> --}}

                                            {{ Form::label('bp_organisation_type', 'Business Partner Organization Type *') }}
                                            {{ Form::select('bp_organisation_type', $bpOrgType, null, ['class' => 'form-control', 'placeholder' => 'Select Business Partner Organization Type', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('residential_status', 'Residential status *') }}
                                            {{ Form::select('residential_status', ['resident' => 'Resident', 'non-resident' => 'Non Resident', 'indian-company' => 'Indian company', 'foriegn-company' => 'Foriegn company'], null, ['class' => 'form-control', 'placeholder' => 'Select Residential status', 'required' => true]) }}
                                        </div>
                                    </div>


                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{-- {{dd($admin_users)}} --}}
                                            {{ Form::label('bp_category', 'Business Partner Category *') }}
                                            <!-- {{ Form::text('bp_category', null, ['class' => 'form-control', 'placeholder' => 'Business Partner Category', 'required' => true]) }} -->
                                            {{ Form::select('bp_category', $business_partner_category, null, ['class' => 'form-control', 'placeholder' => 'Business Partner Category', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bp_group', 'Business Partner group *') }}
                                            {{ Form::text('bp_group', null, ['class' => 'form-control', 'placeholder' => 'Business Partner Group', 'required' => true]) }}
                                        </div>
                                    </div>




                                    <div class="col-md-6 col-12 d-none sm_dynamic">

                                        <div class="form-label-group">
                                            {{ Form::label('sales_manager', 'Sales Manager *') }}
                                            {{ Form::select('sales_manager', $sales_manager, null, ['class' => 'form-control', 'placeholder' => 'Sales Manager']) }}
                                        </div>

                                        {{-- <div class="form-label-group">
                                            {{ Form::label('sales_manager', 'Sales Manager *') }}
                                            {{ Form::text('sales_manager', null, ['class' => 'form-control', 'placeholder' => 'Sales Manager', 'required' => true]) }}
                                        </div> --}}
                                    </div>

                                    <div class="col-md-6 col-12 d-none sm_dynamic">

                                        <div class="form-label-group">
                                            {{ Form::label('sales_officer', 'Sales Officer *') }}
                                            {{ Form::select('sales_officer', $sales_officer, null, ['class' => 'form-control', 'placeholder' => 'Sales Officer']) }}
                                        </div>
                                        {{-- <div class="form-label-group">
                                            {{ Form::label('sales_officer', 'Sales Officer *') }}
                                            {{ Form::text('sales_officer', null, ['class' => 'form-control', 'placeholder' => 'Sales Officer', 'required' => true]) }}
                                        </div> --}}
                                    </div>

                                    <div class="col-md-6 col-12 d-none sm_dynamic">
                                        <div class="form-label-group">
                                            {{ Form::label('salesman', 'Salesman *') }}
                                            {{ Form::select('salesman', $salesman, null, ['class' => 'form-control', 'placeholder' => 'Salesman']) }}
                                        </div>
                                        {{-- <div class="form-label-group">
                                            {{ Form::label('salesman', 'Salesman *') }}
                                            {{ Form::text('salesman', null, ['class' => 'form-control', 'placeholder' => 'Salesman', 'required' => true]) }}
                                        </div> --}}
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{-- {{ Form::label('terms_peyment', 'Terms of Payment *') }}
                                            <select name="payment_terms_id" id="payment_terms" class="form-control"
                                                placeholder='Select Terms of Payment' required>
                                                <option value="">Select Terms of Payment</option>
                                                @foreach ($termPayment as $terms)
                                                    <option value="{{ $terms->payment_terms_id }}">
                                                        {{ $terms->term_type }} </option>
                                                @endforeach

                                            </select> --}}

                                            {{ Form::label('payment_terms_id', 'Terms of Payment *') }}
                                            {{ Form::select('payment_terms_id', $termPayment, null, ['class' => 'form-control', 'placeholder' => 'Select Terms of Payment', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none show_credit_days">
                                        <div class="form-label-group">
                                            {{ Form::label('credit_limit', 'Credit Limit *') }}
                                            {{ Form::text('credit_limit', null, ['class' => 'form-control', 'placeholder' => 'Enter Days']) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('gst_details', 'GST Number *') }}
                                            {{ Form::text('gst_details', null, ['class' => 'form-control', 'placeholder' => 'GST Number', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('gst_reg_type', 'GST Registration Type *') }}
                                            {{ Form::select('gst_reg_type', ['composite' => 'Composite', 'regular' => 'Regular'], null, ['class' => 'form-control', 'placeholder' => 'Select GST Registration Type', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('rcm_app', 'RCM Application *') }}
                                            {{ Form::select('rcm_app', ['1' => 'Yes', '0' => 'No'], null, ['class' => 'form-control', 'required' => true]) }}
                                        </div>
                                    </div>


                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('pricing_profile', 'Pricing Profile *') }}
                                            {{ Form::select('pricing_profile', ['0' => 'dummy data'], null, ['class' => 'form-control', 'placeholder' => 'Select Pricing Profile', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none shelf_left">
                                        <div class="form-label-group">
                                            {{ Form::label('shelf_life', 'Shelf Life *') }}
                                            {{ Form::text('shelf_life', null, ['class' => 'form-control', 'placeholder' => 'Shelf Life']) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 ">
                                        <div class="form-label-group">
                                            {{ Form::label('msme_reg', 'MSME registration *') }}
                                            {{ Form::select('msme_reg', ['1' => 'Yes', '0' => 'No'], null, ['class' => 'form-control', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <hr>

                                    {{-- Address Details --}}

                                    <div class="col-md-12 col-12 mt-3">
                                        <h4><strong>Address Details</strong></h4>
                                    </div>
                                    <div class="ml-3 mt-2 mb-2">
                                    {{-- <input type="checkbox" id="filladdress" name="filladdress"/> --}}
                                    {{ Form::checkbox('filladdress',null,null, array('id'=>'filladdress')) }}
                                    <span><b>Copy Same Address To Ship Address</b></span> 
                                </div>
                                    <div class="col-sm-12">
                          
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class=" col-12">

                                                    <div class="form-label-group">
                                                        {{-- {{ Form::text('address_type', null, ['class' => 'form-control', 'placeholder' => 'Address Type', 'required' => true]) }} --}}
                                                        {{ Form::label('address_type', 'Address Type') }}
                                                        <select name="address_type" id="address_type" class='form-control'>
                                                            {{-- <option value="Official">Official</option> --}}
                                                            <option value="Bill-To/ Bill-From" selected>Bill-To/ Bill-From
                                                            </option>
                                                            <!-- <option value="Ship-To/ Ship-From">Ship-To/ Ship-From</option> -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('building_no_name', 'Building No and Name ') }}
                                                        {{ Form::text('building_no_name', null, ['class' => 'form-control', 'placeholder' => 'Building No and Name', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('street_name', 'Street Name ') }}
                                                        {{ Form::text('street_name', null, ['class' => 'form-control', 'placeholder' => 'Street Name', 'required' => true]) }}
                                                    </div>
                                                </div>
                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('landmark', 'Landmark ') }}
                                                        {{ Form::text('landmark', null, ['class' => 'form-control', 'placeholder' => 'Landmark', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('city', 'Name of City ') }}
                                                        {{ Form::text('city', null, ['class' => 'form-control', 'placeholder' => 'Name of City', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('pin_code', 'Pin Code ') }}
                                                        {{ Form::number('pin_code', null, ['class' => 'form-control', 'onkeypress' => 'return event.charCode === 0 || /\d/.test(String.fromCharCode(event.charCode));', 'placeholder' => 'Pin Code', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('district', 'District ') }}
                                                        {{ Form::text('district', null, ['class' => 'form-control', 'placeholder' => 'District', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('state', 'State') }}
                                                        {{ Form::text('state', null, ['class' => 'form-control', 'placeholder' => 'State', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('country', 'Country') }}
                                                        {{ Form::text('country', null, ['class' => 'form-control', 'placeholder' => 'Country', 'required' => true]) }}
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class=" col-12">

                                                    <div class="form-label-group">
                                                        {{-- {{ Form::text('address_type', null, ['class' => 'form-control', 'placeholder' => 'Address Type', 'required' => true]) }} --}}
                                                        {{ Form::label('address_type1', 'Address Type') }}
                                                        <select name="address_type1" id="address_type1"
                                                            class='form-control'>
                                                            {{-- <option value="Official">Official</option> --}}
                                                            <!-- <option value="Bill-To/ Bill-From">Bill-To/ Bill-From</option> -->
                                                            <option value="Ship-To/ Ship-From" selected>Ship-To/ Ship-From
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('building_no_name1', 'Building No and Name ') }}
                                                        {{ Form::text('building_no_name1', null, ['class' => 'form-control', 'placeholder' => 'Building No and Name', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('street_name1', 'Street Name ') }}
                                                        {{ Form::text('street_name1', null, ['class' => 'form-control', 'placeholder' => 'Street Name', 'required' => true]) }}
                                                    </div>
                                                </div>
                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('landmark1', 'Landmark ') }}
                                                        {{ Form::text('landmark1', null, ['class' => 'form-control', 'placeholder' => 'Landmark', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('city1', 'Name of City ') }}
                                                        {{ Form::text('city1', null, ['class' => 'form-control', 'placeholder' => 'Name of City', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('pin_code1', 'Pin Code ') }}
                                                        {{ Form::number('pin_code1', null, ['class' => 'form-control', 'onkeypress' => 'return event.charCode === 0 || /\d/.test(String.fromCharCode(event.charCode));', 'placeholder' => 'Pin Code', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('district1', 'District ') }}
                                                        {{ Form::text('district1', null, ['class' => 'form-control', 'placeholder' => 'District', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('state1', 'State') }}
                                                        {{ Form::text('state1', null, ['class' => 'form-control', 'placeholder' => 'State', 'required' => true]) }}
                                                    </div>
                                                </div>

                                                <div class=" col-12">
                                                    <div class="form-label-group">
                                                        {{ Form::label('country1', 'Country') }}
                                                        {{ Form::text('country1', null, ['class' => 'form-control', 'placeholder' => 'Country', 'required' => true]) }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- Address Details --}}

                                    </div> {{-- main row --}}
                                    <div class="col-md-12 col-12 mt-3">
                                        <h4><strong>Contact Details</strong></h4>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('type', 'Address Type') }}


                                            {{ Form::select(
                                                'type',
                                                ['Bill-To/ Bill-From' => 'Bill-To/ Bill-From', 'Ship-To/ Ship-From' => 'Ship-To/ Ship-From'],
                                                null,
                                                ['class' => 'form-control 2', 'required' => true],
                                            ) }}

                                        </div>
                                    </div>


                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('contact_person', 'Contact Person Name') }}
                                            {{ Form::text('contact_person', null, ['class' => 'form-control', 'placeholder' => 'Contact Person Name', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('email_id', 'Email') }}
                                            {{ Form::text('email_id', null, ['class' => 'form-control', 'placeholder' => 'Email', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('mobile_no', 'Mobile No') }}
                                            {{ Form::number('mobile_no', null, ['class' => 'form-control', 'onkeypress' => 'return event.charCode === 0 || /\d/.test(String.fromCharCode(event.charCode));', 'placeholder' => 'Mobile No', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('landline', 'Landline') }}
                                            {{ Form::text('landline', null, ['class' => 'form-control', 'placeholder' => 'Landline', 'required' => true]) }}
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-12 mt-3">
                                        <h4><strong>Banking Details</strong></h4>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('acc_holdername', 'Account Holder Name') }}
                                            {{ Form::text('acc_holdername', null, ['class' => 'form-control', 'placeholder' => 'Account Holder Name', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bank_name', 'Bank Name') }}
                                            {{ Form::text('bank_name', null, ['class' => 'form-control', 'placeholder' => 'Bank Name', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bank_branch', 'Branch Name') }}
                                            {{ Form::text('bank_branch', null, ['class' => 'form-control', 'placeholder' => 'Branch Name', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('ifsc', 'IFSC Code') }}
                                            {{ Form::text('ifsc', null, ['class' => 'form-control', 'maxlength' => '15', 'placeholder' => 'IFSC Code', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('ac_number', 'Account No') }}
                                            {{ Form::text('ac_number', null, ['class' => 'form-control', 'placeholder' => 'Account No', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bank_address', 'Bank Address') }}
                                            {{ Form::text('bank_address', null, ['class' => 'form-control', 'placeholder' => 'Bank Address', 'required' => true]) }}
                                        </div>
                                    </div>

                                    {{-- end of row --}}

                                    <div class="col-md-12 col-12 mt-3 d-none beat_det">
                                        <h4><strong>Beat Details</strong></h4>
                                    </div>

                                    <div class="col-md-6 col-12 d-none beat_det">
                                        <div class="form-group">
                                            {{ Form::label('area_id', 'Area *') }}
                                            {{ Form::select('area_id', $area_data, '', ['class' => 'form-control select2 area', 'id' => 'area_field', 'placeholder' => 'Select Area']) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none beat_det">
                                        <div class="form-group">
                                            {{ Form::label('route_id', 'Route *') }}
                                            <select name="route_id" id="routes" class="form-control select2"></select>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none beat_det">
                                        <div class="form-group">
                                            {{ Form::label('beat_id', 'Beat *') }}
                                            <select name="beat_id" id="beat" class="form-control select2"></select>
                                        </div>
                                    </div>


                                </div>
                                <div class="row mt-3">
                                    <div class="col md-12 text-center">
                                        {{-- <center> --}}
                                        {{ Form::submit('Save', ['class' => 'btn btn-primary mr-1 mb-1']) }}
                                        <button type="reset" class="btn btn-secondary mr-1 mb-1">Reset</button>
                                        {{-- </center> --}}
                                    </div>
                                </div>

                            </div>


                            {{ Form::close() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- area modal -->
    <div class="modal fade text-left" id="add_area_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Add Area</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('area_name', 'Area Name *') }}
                                {{ Form::text('area_name', null, ['class' => 'form-control', 'placeholder' => 'Enter Area Name', 'required' => true]) }}
                            </div>
                        </div>

                        <div class="col-12 d-flex justify-content-start">
                            <button type="submit" class="btn btn-primary mr-1 mb-1" id="submit_area">Submit</button>
                            <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- route modal -->
    <div class="modal fade text-left" id="add_route_modal" tabindex="-1" role="dialog"
        aria-labelledby="myModalLabel1" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Add Route</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('route_name', 'Route Name *') }}
                                {{ Form::text('route_name', null, ['class' => 'form-control', 'placeholder' => 'Enter Route Name', 'required' => true]) }}
                            </div>
                        </div>
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('area_id', 'Select Area *') }}
                                <select name="area_id" id="area_id1" class="form-control select2"></select>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-start">
                        <button type="submit" class="btn btn-primary mr-1 mb-1" id="submit_route">Submit</button>
                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>


    <!-- beat modal -->
    <div class="modal fade text-left" id="add_beat_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Add Beat</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('beat_name', 'Beat Name *') }}
                                {{ Form::text('beat_name', null, ['class' => 'form-control', 'placeholder' => 'Enter Beat Name', 'required' => true]) }}
                            </div>
                        </div>


                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{-- {{dd($area_data)}} --}}
                                {{ Form::label('area_id', 'Select Area *') }}
                                {{ Form::select('area_id', $area_data, request()->area_id, ['class' => 'select2 form-control', 'placeholder' => 'Select Area', 'id' => 'area_id']) }}
                            </div>
                        </div>

                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('route_id', 'Select Route *') }}
                                <select name="route_id" id="route_id" class="form-control select2"></select>
                                {{-- {{ Form::select('route_id', $route_data, request()->route_id, ['class'=>'select2 form-control','id'=>'route_id']) }} --}}
                            </div>
                        </div>


                    </div>
                    <div class="col-12 d-flex justify-content-start">
                        <button type="submit" class="btn btn-primary mr-1 mb-1" id="submit_beat">Submit</button>
                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>


    {{-- add data for area,route and beat --}}
    <script>
        $(document).ready(function() {





            // new item add for area
            $(document).on('click', '#open_area_modal', function() {
                // console.log('test in brand');
                $('#area_field').select2('close');
                $('#add_area_modal').modal('show');
            });
            $('#submit_area').on('click', function() {
                var area_name = $("#area_name", $('#add_area_modal')).val();
                if (area_name != '') {
                    console.log('in');
                    $.ajax({
                        url: '{{ url('admin/area/store') }}',
                        type: 'post',
                        data: {
                            area_name: area_name,
                            _token: "{{ csrf_token() }}",
                            form_type: 'area_modal',
                        },
                        dataType: 'json',
                        success: function(data) {
                            // console.log(data['brands']);
                            if (data.flag == 'success') {
                                alert(data['message']);
                                $("#area_field").html(data['area']);
                                $('#add_area_modal').modal('hide');
                            } else {
                                alert(data['message']);
                                $('#add_area_modal').modal('hide');
                            }
                        }
                    });
                    // $('#add_area_modal').modal('show');
                }
            });
            $('.select2').select2();
            var areadropdowncnt = 1;
            $('#area_field').on('select2:open', function() {
                let brand_options = $(this).data('select2');
                if (!$('.select2-link').length) {
                    if (areadropdowncnt == 1) {
                        brand_options.$results.parents('.select2-results')
                            .append(
                                '<div class=" m-2 select2-link2 select2-close text-right"><button id="open_area_modal" class="btn btn-secondary">Add New Item +</button></div>'
                            )
                            .on('click', function(b) {
                                // $('#add_area_modal').modal('show');
                            });
                        areadropdowncnt++;
                    }
                }
            });


            //add new item for route
            var routedropdowncnt = 1;
            $('#routes').on('select2:open', function() {
                let category_options = $(this).data('select2');
                if (!$('.select2-link').length) {
                    if (routedropdowncnt == 1) {
                        category_options.$results.parents('.select2-results')
                            .append(
                                '<div class="m-2 select2-link2 select2-close text-right"><button id="open_route_modal" class="btn btn-secondary">Add New Item +</button></div>'
                            )
                            .on('click', function(b) {
                                // $('#add_area_modal').modal('show');
                            });
                        routedropdowncnt++;
                    }
                }
            });
            // alert(routedropdowncnt);
            $(document).on('click', '#open_route_modal', function() {
                // console.log('test in category');
                $('#routes').select2('close');

                //get areas data again before opening modal
                $.ajax({
                    method: 'post',
                    headers: {
                        'X-CSRF-Token': '{{ csrf_token() }}',
                    },
                    url: '{{ route('admin.areas') }}',
                    dataType: 'json',
                    success: function(data) {
                        // console.log(data);      
                        if (data != '') {
                            $('#area_id1').html('<option value="">Select Area</option>');
                            $.each(data, function(key, value) {
                                $("#area_id1").append('<option value="' + key + '">' +
                                    value + '</option>');
                            });
                        } else {
                            $('#area_id1').html('<option value="">Select Area</option>');
                        }

                    }
                });


                $('#add_route_modal').modal('show');
            });
            $('#submit_route').on('click', function() {

                var area = $("#area_field option:selected").val();
                var route_name = $("#route_name", $('#add_route_modal')).val();
                var area_id = $("#area_id1", $('#add_route_modal')).val();
                if (route_name != '') {

                    $.ajax({
                        url: '{{ url('admin/route/store') }}',
                        type: 'post',
                        data: {
                            route_name: route_name,
                            area_id: area_id,
                            area: area,
                            _token: "{{ csrf_token() }}",
                            form_type: 'route_modal',
                        },
                        dataType: 'json',
                        success: function(data) {
                            console.log(data['routes']);
                            if (data.flag == 'success') {
                                alert(data['message']);
                                $("#routes").html(data['routes']);
                                $('#add_route_modal').modal('hide');
                            } else {
                                alert(data['message']);
                                // console.log(data);
                                $('#add_route_modal').modal('hide');

                            }
                        }
                    });
                    // $('#add_area_modal').modal('show');
                }
            });

            //add new item for beat
            var beatdropdowncnt = 1;
            $('#beat').on('select2:open', function() {
                let sub_category_options = $(this).data('select2');
                if (!$('.select2-link').length) {
                    if (beatdropdowncnt == 1) {
                        sub_category_options.$results.parents('.select2-results')
                            .append(
                                '<div class="m-2 select2-link2 select2-close text-right"><button id="open_beat_modal" class="btn btn-secondary">Add New Item +</button></div>'
                            )
                            .on('click', function(b) {
                                // $('#add_area_modal').modal('show');
                            });
                        beatdropdowncnt++;
                    }
                }
            });
            $(document).on('click', '#open_beat_modal', function() {
                // console.log('test in sub category');
                $('#beat').select2('close');
                //get areas data again before opening modal
                $.ajax({
                    method: 'post',
                    headers: {
                        'X-CSRF-Token': '{{ csrf_token() }}',
                    },
                    url: '{{ route('admin.areas') }}',
                    dataType: 'json',
                    success: function(data) {
                        // console.log(data);      
                        if (data != '') {
                            $('#area_id').html('<option value="">Select Area</option>');
                            $.each(data, function(key, value) {
                                $("#area_id").append('<option value="' + key + '">' +
                                    value + '</option>');
                            });
                        } else {
                            $('#area_id').html('<option value="">Select Area</option>');
                        }

                    }
                });



                $('#add_beat_modal').modal('show');
            });
            $('#submit_beat').on('click', function() {

                var route = $("#routes option:selected").val();
                var area = $("#area_field option:selected").val();
                var beat_name = $("#beat_name", $('#add_beat_modal')).val();
                var area_id = $("#area_id", $('#add_beat_modal')).val();
                var route_id = $("#route_id", $('#add_beat_modal')).val();


                if (route_id != '' && area_id != '') {
                    // console.log('in');
                    $.ajax({
                        url: '{{ url('admin/beat/store') }}',
                        type: 'post',
                        data: {
                            beat_name: beat_name,
                            area_id: area_id,
                            route_id: route_id,
                            area: area,
                            route: route,
                            _token: "{{ csrf_token() }}",
                            form_type: 'beat_modal',
                        },
                        dataType: 'json',
                        success: function(data) {
                            // console.log(data['brands']);
                            if (data.flag == 'success') {
                                alert(data['message']);
                                $("#beat").html(data['beat']);
                                $('#add_beat_modal').modal('hide');
                            } else {
                                alert(data['message']);
                                // console.log(data);
                                $('#add_beat_modal').modal('hide');

                            }
                        }
                    });
                    // $('#add_area_modal').modal('show');
                }
            });

        });
    </script>


    <script>
        $(document).ready(function() {
            var bptype = $('#business_partner_type').find('option:selected').text();

            if (bptype == 'Customer') {
                $('.sm_dynamic').removeClass('d-none');
                $('.shelf_left').removeClass('d-none');
                $('.beat_det').removeClass('d-none');
            } else {
                $('.sm_dynamic').addClass('d-none');
                $('.shelf_left').addClass('d-none');
                $('.beat_det').addClass('d-none');
            }

            var terms_of_payment = $('#payment_terms_id').find('option:selected').text();
            if (terms_of_payment == 'On Credit') {
                $('.show_credit_days').removeClass('d-none');
            } else {
                $('.show_credit_days').addClass('d-none');
            }


        $("#filladdress").on("click", function(){
        if (this.checked) { 
                $("#building_no_name1").val($("#building_no_name").val());
                $("#street_name1").val($("#street_name").val());
                $("#landmark1").val($("#landmark").val());                         
                $("#city1").val($("#city").val());                         
                $("#pin_code1").val($("#pin_code").val());                         
                $("#district1").val($("#district").val());                         
                $("#state1").val($("#state").val());                         
                $("#country1").val($("#country").val());                         
            }
            
        });
        });

        $('#business_partner_type').on('change', function() {
            var bptype = $(this).find('option:selected').text();
            if (bptype == 'Customer') {
                $('.sm_dynamic').removeClass('d-none');
                $('.shelf_left').removeClass('d-none');
                $('.beat_det').removeClass('d-none');
            } else {
                $('.sm_dynamic').addClass('d-none');
                $('.shelf_left').addClass('d-none');
                $('.beat_det').addClass('d-none');
            }
        });

        $('#payment_terms_id').on('change', function() {
            var terms_of_payment = $(this).find('option:selected').text();
            if (terms_of_payment == 'On Credit') {
                $('.show_credit_days').removeClass('d-none');
            } else {
                $('.show_credit_days').addClass('d-none');
            }
        });
    </script>




@endsection
