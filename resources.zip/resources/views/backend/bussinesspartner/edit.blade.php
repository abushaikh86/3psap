@extends('backend.layouts.app')
@section('title', 'Edit Business Partner')
@php
    use Spatie\Permission\Models\Role;
@endphp
@section('content')
    {{-- {{ dd($bussinesspartner->toArray()) }} --}}

    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Edit Business Partner</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">Edit</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-header-right col-md-6 col-12 mb-md-0 mb-2">
            <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">
                <div class="btn-group" role="group">
                    <a class="btn btn-outline-primary" href="{{ route('admin.bussinesspartner') }}">
                        <i class="feather icon-eye"></i> Back
                    </a>
                </div>
            </div>
        </div>
    </div>
    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body card-dashboard">
                            @include('backend.includes.errors')
                            {{ Form::open(['url' => 'admin/bussinesspartner/update']) }}
                            @csrf
                            <div class="form-body">

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('Business Partner Type', 'Business Partner Type *') }}
                                            {{-- <select name="business_partner_type" id="business_partner_type"
                                                class="form-control" placeholder='Select Business Partner Type' required>
                                                @foreach ($bussinesstype as $btype)
                                                    <option value="{{ $btype->bussiness_master_type_id }}"
                                                        @if ($bussinesspartner->bussiness_master_type_id == $btype->bussiness_master_type_id) Selected @endif>
                                                        {{ $btype->bussiness_master_type }}</option>
                                                @endforeach
                                            </select> --}}
                                            {{ Form::select('business_partner_type', $bussiness_master_type, $model->business_partner_type, ['class' => 'form-control','id'=>'business_partner_type', 'placeholder' => 'Select Pricing Profile', 'required' => true]) }}

                                            {{-- hidden field for bussiness partner id  --}}
                                            {{ Form::hidden('business_partner_id', $model->business_partner_id, ['class' => 'form-control']) }}
                                            {{-- {{ Form::hidden('bp_address_id1', $business_partner_address[0]->bp_address_id, ['class' => 'form-control']) }}
                                            {{ Form::hidden('bp_address_id2', $business_partner_address[1]->bp_address_id, ['class' => 'form-control']) }} --}}

                                        </div>
                                    </div>
                                    {{-- <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bp_code', 'Business Partner Code *') }}
                                            {{ Form::text('bp_code', $model->bp_code, ['class' => 'form-control', 'placeholder' => 'Business Partner Code', 'required' => true]) }}
                                        </div>
                                    </div> --}}

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bp_name', 'Business Partner Name *') }}
                                            {{ Form::text('bp_name', $model->bp_name, ['class' => 'form-control', 'placeholder' => 'Business Partner Name', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('Business Partner Organization Type', 'Business Partner Organization Type *') }}
                                            {{-- <select name="bp_organisation_type" id="bp_organisation_type"
                                            <select name="business_partner_type" id="business_partner_type"
                                                class="form-control" placeholder='Select Business Organization Type' required>
                                                @foreach ($bpOrgType as $OrgType)
                                                    <option value="{{ $OrgType->bp_organisation_type_id }}"
                                                        @if ($model->bp_organisation_type_id == $OrgType->bp_organisation_type_id) selected @endif>
                                                        {{ $OrgType->bp_organisation_type }}</option>
                                                @endforeach

                                            </select> --}}
                                            {{ Form::select('bp_organisation_type', $bpOrgType, $model->bp_organisation_type, ['class' => 'form-control', 'placeholder' => 'Select Business Partner Organization Type', 'required' => true]) }}

                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('residential_status', 'Residential status *') }}
                                            {{ Form::select('residential_status', ['resident' => 'Resident', 'non-resident' => 'Non Resident', 'indian-company' => 'Indian company', 'foriegn-company' => 'Foriegn company'], $model->residential_status, ['class' => 'form-control', 'placeholder' => 'Select Residential status', 'required' => true]) }}
                                        </div>
                                    </div>


                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bp_category', 'Business Partner Category *') }}
                                            {{ Form::select('bp_category', $business_partner_category, $model->bp_category, ['class' => 'form-control', 'placeholder' => 'Business Partner Category', 'required' => true]) }}

                                            {{-- {{ Form::text('bp_category', $model->bp_category, ['class' => 'form-control', 'placeholder' => 'Business Partner Category', 'required' => true]) }} --}}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('bp_group', 'Business Partner group *') }}
                                            {{ Form::text('bp_group', $model->bp_group, ['class' => 'form-control', 'placeholder' => 'Business Partner Group', 'required' => true]) }}
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 d-none sm_dynamic">
                                        {{ Form::label('Sales Manager', 'Sales Manager *') }}
                                        <select name="sales_manager" id="sales_manager" class="form-control"
                                            placeholder='Select Manager' >
                                            <option value="">Select</option>
                                            @foreach ($admin_users as $btype)
                                                @if ($btype->role == 12)
                                                    <option value="{{ $btype->admin_user_id }}"
                                                        @if ($model->sales_manager == $btype->admin_user_id) Selected @endif>
                                                        {{ $btype->first_name }}</option>
                                                @endif
                                            @endforeach
                                        </select>


                                        {{-- <div class="form-label-group">
                                            {{ Form::label('sales_manager', 'Sales Manager *') }}
                                            {{ Form::text('sales_manager', $model->sales_manager, ['class' => 'form-control', 'placeholder' => 'Sales Manager', 'required' => true]) }}
                                        </div>  --}}
                                    </div>

                                    <div class="col-md-6 col-12 d-none sm_dynamic">
                                        {{ Form::label('Sales Officer', 'Sales Officer *') }}
                                        <select name="sales_officer" id="sales_officer" class="form-control"
                                            placeholder='Select Officer' >
                                            <option value="">Select</option>
                                            @foreach ($admin_users as $btype)
                                                @if ($btype->role == 10)
                                                    <option value="{{ $btype->admin_user_id }}"
                                                        @if ($model->sales_officer == $btype->admin_user_id) Selected @endif>
                                                        {{ $btype->first_name }}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                        {{-- <div class="form-label-group">
                                            {{ Form::label('sales_officer', 'Sales Officer *') }}
                                            {{ Form::text('sales_officer', $model->sales_officer, ['class' => 'form-control', 'placeholder' => 'Sales Officer', 'required' => true]) }}
                                        </div> --}}
                                    </div>

                                    <div class="col-md-6 col-12 d-none sm_dynamic">

                                        {{ Form::label('Salesman', 'Salesman *') }}
                                        <select name="salesman" id="salesman" class="form-control"
                                            placeholder='Select Salesman' >
                                            <option value="">Select</option>
                                            @foreach ($admin_users as $btype)
                                                @if ($btype->role == 11)
                                                    <option value="{{ $btype->admin_user_id }}"
                                                        @if ($model->salesman == $btype->admin_user_id) Selected @endif>
                                                        {{ $btype->first_name }}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                        {{-- <div class="form-label-group">
                                            {{ Form::label('salesman', 'Salesman *') }}
                                            {{ Form::text('salesman', $model->salesman, ['class' => 'form-control', 'placeholder' => 'Salesman', 'required' => true]) }}
                                        </div> --}}
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('terms_peyment', 'Terms of Payment *') }}
                                            <select name="payment_terms_id" id="payment_terms_id" class="form-control"
                                                placeholder='Select Terms of Payment' required>
                                                @foreach ($termPayment as $terms)
                                                    <option value="{{ $terms->payment_terms_id }}"
                                                        @if ($model->payment_terms_id == $terms->payment_terms_id) Selected = selected @endif>{{ $terms->term_type }}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none show_credit_days">
                                        <div class="form-label-group">
                                            {{ Form::label('credit_limit', 'Credit Limit *') }}
                                            {{ Form::text('credit_limit', $model->credit_limit, ['class' => 'form-control', 'placeholder' => 'Enter Days']) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('gst_details', 'GST Number *') }}
                                            {{ Form::text('gst_details', $model->gst_details, ['class' => 'form-control', 'placeholder' => 'GST Number', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('gst_reg_type', 'GST Registration Type *') }}
                                            {{ Form::select('gst_reg_type', ['composite' => 'Composite', 'regular' => 'Regular'], $model->gst_reg_type, ['class' => 'form-control', 'placeholder' => 'Select GST Registration Type', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('rcm_app', 'RCM Application *') }}
                                            {{ Form::select('rcm_app', ['1' => 'Yes', '0' => 'No'], $model->rcm_app, ['class' => 'form-control', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-label-group">
                                            {{ Form::label('pricing_profile', 'Pricing Profile *') }}
                                            {{ Form::select('pricing_profile', ['0' => 'dummy data'], $model->pricing_profile, ['class' => 'form-control', 'placeholder' => 'Select Pricing Profile', 'required' => true]) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none shelf_left">
                                        <div class="form-label-group">
                                            {{ Form::label('shelf_life', 'Shelf Life *') }}
                                            {{ Form::text('shelf_life', $model->shelf_life, ['class' => 'form-control', 'placeholder' => 'Shelf Life']) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 ">
                                        <div class="form-label-group">
                                            {{ Form::label('msme_reg', 'MSME registration *') }}
                                            {{ Form::select('msme_reg', ['1' => 'Yes', '0' => 'No'], $model->msme_reg, ['class' => 'form-control', 'required' => true]) }}
                                        </div>
                                    </div>



                                    <div class="col-md-12 col-12 mt-3 d-none beat_det">
                                        <h4><strong>Beat Details</strong></h4>
                                    </div>

                                    <div class="col-md-6 col-12 d-none beat_det">
                                        <div class="form-group">
                                            {{ Form::label('area_id', 'Area *') }}
                                            {{ Form::select('area_id', $area_data, $model->area_id, ['class' => 'form-control select2 area', 'id' => 'area_field', 'placeholder' => 'Select Area']) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none beat_det">
                                        <div class="form-group">
                                            {{ Form::label('route_id', 'Route *') }}
                                            <select name="route_id" id="routes" class="form-control select2"></select>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 d-none beat_det">
                                        <div class="form-group">
                                            {{ Form::label('beat_id', 'Beat *') }}
                                            <select name="beat_id" id="beat" class="form-control select2"></select>
                                        </div>
                                    </div>




                                </div> {{-- main row --}}
                            </div>
                            <div class="col md-12 text-center mt-3">

                                {{ Form::submit('Save', ['class' => 'btn btn-primary mr-1 mb-1']) }}
                                <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>

                            </div>

                        </div>


                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

    {{-- beat details js --}}

    <!-- area modal -->
    <div class="modal fade text-left" id="add_area_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Add Area</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('area_name', 'Area Name *') }}
                                {{ Form::text('area_name', null, ['class' => 'form-control', 'placeholder' => 'Enter Area Name', 'required' => true]) }}
                            </div>
                        </div>

                        <div class="col-12 d-flex justify-content-start">
                            <button type="submit" class="btn btn-primary mr-1 mb-1" id="submit_area">Submit</button>
                            <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- route modal -->
    <div class="modal fade text-left" id="add_route_modal" tabindex="-1" role="dialog"
        aria-labelledby="myModalLabel1" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Add Route</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('route_name', 'Route Name *') }}
                                {{ Form::text('route_name', null, ['class' => 'form-control', 'placeholder' => 'Enter Route Name', 'required' => true]) }}
                            </div>
                        </div>
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('area_id', 'Select Area *') }}
                                <select name="area_id" id="area_id1" class="form-control select2"></select>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-start">
                        <button type="submit" class="btn btn-primary mr-1 mb-1" id="submit_route">Submit</button>
                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>


    <!-- beat modal -->
    <div class="modal fade text-left" id="add_beat_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Add Beat</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('beat_name', 'Beat Name *') }}
                                {{ Form::text('beat_name', null, ['class' => 'form-control', 'placeholder' => 'Enter Beat Name', 'required' => true]) }}
                            </div>
                        </div>


                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{-- {{dd($area_data)}} --}}
                                {{ Form::label('area_id', 'Select Area *') }}
                                {{ Form::select('area_id', $area_data, request()->area_id, ['class' => 'select2 form-control', 'placeholder' => 'Select Area', 'id' => 'area_id']) }}
                            </div>
                        </div>

                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                {{ Form::label('route_id', 'Select Route *') }}
                                <select name="route_id" id="route_id" class="form-control select2"></select>
                                {{-- {{ Form::select('route_id', $route_data, request()->route_id, ['class'=>'select2 form-control','id'=>'route_id']) }} --}}
                            </div>
                        </div>


                    </div>
                    <div class="col-12 d-flex justify-content-start">
                        <button type="submit" class="btn btn-primary mr-1 mb-1" id="submit_beat">Submit</button>
                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>


    {{-- add data for area,route and beat --}}
    <script>
        $(document).ready(function() {





            // new item add for area
            $(document).on('click', '#open_area_modal', function() {
                // console.log('test in brand');
                $('#area_field').select2('close');
                $('#add_area_modal').modal('show');
            });
            $('#submit_area').on('click', function() {
                var area_name = $("#area_name", $('#add_area_modal')).val();
                if (area_name != '') {
                    console.log('in');
                    $.ajax({
                        url: '{{ url('admin/area/store') }}',
                        type: 'post',
                        data: {
                            area_name: area_name,
                            _token: "{{ csrf_token() }}",
                            form_type: 'area_modal',
                        },
                        dataType: 'json',
                        success: function(data) {
                            // console.log(data['brands']);
                            if (data.flag == 'success') {
                                alert(data['message']);
                                $("#area_field").html(data['area']);
                                $('#add_area_modal').modal('hide');
                            } else {
                                alert(data['message']);
                                $('#add_area_modal').modal('hide');
                            }
                        }
                    });
                    // $('#add_area_modal').modal('show');
                }
            });
            $('.select2').select2();
            var areadropdowncnt = 1;
            $('#area_field').on('select2:open', function() {
                let brand_options = $(this).data('select2');
                if (!$('.select2-link').length) {
                    if (areadropdowncnt == 1) {
                        brand_options.$results.parents('.select2-results')
                            .append(
                                '<div class=" m-2 select2-link2 select2-close text-right"><button id="open_area_modal" class="btn btn-secondary">Add New Item +</button></div>'
                            )
                            .on('click', function(b) {
                                // $('#add_area_modal').modal('show');
                            });
                        areadropdowncnt++;
                    }
                }
            });


            //add new item for route
            var routedropdowncnt = 1;
            $('#routes').on('select2:open', function() {
                let category_options = $(this).data('select2');
                if (!$('.select2-link').length) {
                    if (routedropdowncnt == 1) {
                        category_options.$results.parents('.select2-results')
                            .append(
                                '<div class="m-2 select2-link2 select2-close text-right"><button id="open_route_modal" class="btn btn-secondary">Add New Item +</button></div>'
                            )
                            .on('click', function(b) {
                                // $('#add_area_modal').modal('show');
                            });
                        routedropdowncnt++;
                    }
                }
            });
            // alert(routedropdowncnt);
            $(document).on('click', '#open_route_modal', function() {
                // console.log('test in category');
                $('#routes').select2('close');

                //get areas data again before opening modal
                $.ajax({
                    method: 'post',
                    headers: {
                        'X-CSRF-Token': '{{ csrf_token() }}',
                    },
                    url: '{{ route('admin.areas') }}',
                    dataType: 'json',
                    success: function(data) {
                        // console.log(data);      
                        if (data != '') {
                            $('#area_id1').html('<option value="">Select Area</option>');
                            $.each(data, function(key, value) {
                                $("#area_id1").append('<option value="' + key + '">' +
                                    value + '</option>');
                            });
                        } else {
                            $('#area_id1').html('<option value="">Select Area</option>');
                        }

                    }
                });


                $('#add_route_modal').modal('show');
            });
            $('#submit_route').on('click', function() {

                var area = $("#area_field option:selected").val();
                var route_name = $("#route_name", $('#add_route_modal')).val();
                var area_id = $("#area_id1", $('#add_route_modal')).val();
                if (route_name != '') {

                    $.ajax({
                        url: '{{ url('admin/route/store') }}',
                        type: 'post',
                        data: {
                            route_name: route_name,
                            area_id: area_id,
                            area: area,
                            _token: "{{ csrf_token() }}",
                            form_type: 'route_modal',
                        },
                        dataType: 'json',
                        success: function(data) {
                            console.log(data['routes']);
                            if (data.flag == 'success') {
                                alert(data['message']);
                                $("#routes").html(data['routes']);
                                $('#add_route_modal').modal('hide');
                            } else {
                                alert(data['message']);
                                // console.log(data);
                                $('#add_route_modal').modal('hide');

                            }
                        }
                    });
                    // $('#add_area_modal').modal('show');
                }
            });

            //add new item for beat
            var beatdropdowncnt = 1;
            $('#beat').on('select2:open', function() {
                let sub_category_options = $(this).data('select2');
                if (!$('.select2-link').length) {
                    if (beatdropdowncnt == 1) {
                        sub_category_options.$results.parents('.select2-results')
                            .append(
                                '<div class="m-2 select2-link2 select2-close text-right"><button id="open_beat_modal" class="btn btn-secondary">Add New Item +</button></div>'
                            )
                            .on('click', function(b) {
                                // $('#add_area_modal').modal('show');
                            });
                        beatdropdowncnt++;
                    }
                }
            });
            $(document).on('click', '#open_beat_modal', function() {
                // console.log('test in sub category');
                $('#beat').select2('close');
                //get areas data again before opening modal
                $.ajax({
                    method: 'post',
                    headers: {
                        'X-CSRF-Token': '{{ csrf_token() }}',
                    },
                    url: '{{ route('admin.areas') }}',
                    dataType: 'json',
                    success: function(data) {
                        // console.log(data);      
                        if (data != '') {
                            $('#area_id').html('<option value="">Select Area</option>');
                            $.each(data, function(key, value) {
                                $("#area_id").append('<option value="' + key + '">' +
                                    value + '</option>');
                            });
                        } else {
                            $('#area_id').html('<option value="">Select Area</option>');
                        }

                    }
                });



                $('#add_beat_modal').modal('show');
            });
            $('#submit_beat').on('click', function() {

                var route = $("#routes option:selected").val();
                var area = $("#area_field option:selected").val();
                var beat_name = $("#beat_name", $('#add_beat_modal')).val();
                var area_id = $("#area_id", $('#add_beat_modal')).val();
                var route_id = $("#route_id", $('#add_beat_modal')).val();


                if (route_id != '' && area_id != '') {
                    // console.log('in');
                    $.ajax({
                        url: '{{ url('admin/beat/store') }}',
                        type: 'post',
                        data: {
                            beat_name: beat_name,
                            area_id: area_id,
                            route_id: route_id,
                            area: area,
                            route: route,
                            _token: "{{ csrf_token() }}",
                            form_type: 'beat_modal',
                        },
                        dataType: 'json',
                        success: function(data) {
                            // console.log(data['brands']);
                            if (data.flag == 'success') {
                                alert(data['message']);
                                $("#beat").html(data['beat']);
                                $('#add_beat_modal').modal('hide');
                            } else {
                                alert(data['message']);
                                // console.log(data);
                                $('#add_beat_modal').modal('hide');

                            }
                        }
                    });
                    // $('#add_area_modal').modal('show');
                }
            });

        });
    </script>


<script>
    $(document).ready(function() {
        var bptype = $('#business_partner_type').find('option:selected').text();
        // alert(bptype);

        if (bptype == 'Customer') {
            $('.sm_dynamic').removeClass('d-none');
            $('.shelf_left').removeClass('d-none');
            $('.beat_det').removeClass('d-none');
        } else {
            $('.sm_dynamic').addClass('d-none');
            $('.shelf_left').addClass('d-none');
            $('.beat_det').addClass('d-none');
        }

        var terms_of_payment = $('#payment_terms_id').find('option:selected').text();
        // alert(terms_of_payment);
        if (terms_of_payment == 'On Credit') {
            $('.show_credit_days').removeClass('d-none');
        } else {
            $('.show_credit_days').addClass('d-none');
        }
    });

    $('#business_partner_type').on('change', function() {
        var bptype = $(this).find('option:selected').text();
        if (bptype == 'Customer') {
            $('.sm_dynamic').removeClass('d-none');
            $('.shelf_left').removeClass('d-none');
            $('.beat_det').removeClass('d-none');
        } else {
            $('.sm_dynamic').addClass('d-none');
            $('.shelf_left').addClass('d-none');
            $('.beat_det').addClass('d-none');
        }
    });

    $('#payment_terms_id').on('change', function() {
        var terms_of_payment = $(this).find('option:selected').text();
        if (terms_of_payment == 'On Credit') {
            $('.show_credit_days').removeClass('d-none');
        } else {
            $('.show_credit_days').addClass('d-none');
        }
    });
</script>
@endsection
