@extends('backend.layouts.app')
@section('title', 'Beat Calender')
@php
    use Spatie\Permission\Models\Role;
    use Carbon\CarbonPeriod;
@endphp
@section('content')

    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Create Beat Calender</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('admin.beatcalender') }}">Beat Calender</a>
                        </li>
                        <li class="breadcrumb-item active">Create</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-header-right col-md-6 col-12 mb-md-0 mb-2">
            <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">
                <div class="btn-group" role="group">
                    <a class="btn btn-outline-primary" href="{{ route('admin.beatcalender') }}">
                        <i class="feather icon-eye"></i> view
                    </a>
                </div>
            </div>
        </div>
    </div>


    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body card-dashboard">
                            @include('backend.includes.errors')
                            {{ Form::open(['url' => 'admin/beatcalender/store']) }}
                            @csrf
                            <div class="form-body">
                                <div class="row">

                                    {{-- {{dd($area_data)}} --}}

                                    
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('salesman', 'Salesman *') }}
                                            {{ Form::text('salesman', null, ['class' => 'form-control', 'placeholder' => 'Salesman', 'required' => true]) }}

                                        </div>
                                    </div>

                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('area_id', 'Area *') }}
                                            {{ Form::select('area_id',$area_data,'', array('class' => 'form-control select2','id'=>'area_field','placeholder'=>'Select Area','required'=>true)) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('routes', 'Route *') }}
                                            <select name="route_id" id="routes" class="form-control select2 " required></select>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('beat_id', 'Beat *') }}
                                            <select name="beat_id" id="beat" class="form-control select2"></select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('outlet', 'Outlet *') }}
                                            {{-- {{ Form::select('outlet[]',['0'=>'Outlet 1','1'=>'Outlet 2'] ,null, ['class' => 'form-control','multiple' => 'multiple', 'required' => true]) }} --}}
                                            {!! Form::select('outlet[]',['0'=>'Outlet 1','1'=>'Outlet 2'] ,
                                            null, ['class' => 'form-control tags','multiple' => 'multiple']) !!}
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('sales_execu', 'Sales Executive *') }}
                                            {{ Form::select('sales_execu', $sales_execu_data,null, ['class' => 'form-control', 'placeholder' => 'Select Sales Executive', 'required' => true]) }}
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('ase', 'ASE *') }}
                                            {{ Form::text('ase', null, ['class' => 'form-control', 'placeholder' => 'ASE', 'required' => true]) }}
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            {{ Form::label('asm', 'ASM *') }}
                                            {{ Form::text('asm', null, ['class' => 'form-control', 'placeholder' => 'ASM', 'required' => true]) }}
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            <?php
                                            $week = [
                                            'Week 1',
                                            'Week 2',
                                            'Week 3',
                                            'Week 4',
                                            'Week 5',
                                            ];
                                            ?>

                                            {{ Form::label('beat_week', 'Beat Week *') }}
                                            {{ Form::select('beat_week', $week,null, ['class' => 'form-control', 'placeholder' => 'Select Beat Week', 'required' => true]) }}
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            <?php
                                            $days = [
                                            'Sunday',
                                            'Monday',
                                            'Tuesday',
                                            'Wednesday',
                                            'Thursday',
                                            'Friday',
                                            'Saturday'
                                            ];
                                            ?>
                                            {{ Form::label('beat_day', 'Beat Day *') }}
                                            {!! Form::select('beat_day[]',$days ,
                                            null, ['class' => 'form-control tags','multiple' => 'multiple']) !!}
                                            {{-- {{ Form::select('beat_day',$days,null, ['class' => 'form-control', 'placeholder' => 'Select Beat Day', 'required' => true]) }} --}}
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            <?php
                                            $month_data = CarbonPeriod::create(now()->startOfMonth(), '1 month', now()->addMonths(11)->startOfMonth());
                                            $month_data = collect($month_data)->map(function ($item, $key) {
                                                return date('F', strtotime($item));
                                            })->all();

                                            $month_data = array_combine($month_data,$month_data);
                                            ?>
                                            {{ Form::label('beat_month', 'Beat Month *') }}
                                            {{ Form::select('beat_month',$month_data,null, ['class' => 'form-control', 'placeholder' => 'Select Beat Month', 'required' => true]) }}

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6">
                                        <div class="form-group">
                                            <?php
                                            $year_data = CarbonPeriod::create(now()->startOfYear(), '1 year', now()->addYears(9)->startOfYear());
                                            $year_data = collect($year_data)->map(function ($item, $key) {
                                                return date('Y', strtotime($item));
                                            })->all();

                                            $year_data = array_combine($year_data,$year_data);
                                            ?>

                                            {{ Form::label('beat_year', 'Beat Year *') }}
                                            {{ Form::select('beat_year',$year_data,null, ['class' => 'form-control', 'placeholder' => 'Select Beat Year', 'required' => true]) }}
                           
                                        </div>
                                    </div>
                                </div>


                                    
                               
                                <div class="row mt-3">
                                    <div class="col md-12 ">
                                        {{-- <center> --}}
                                            {{ Form::submit('Save', ['class' => 'btn btn-primary mr-1 mb-1']) }}
                                            <button type="reset" class="btn btn-secondary mr-1 mb-1">Reset</button>
                                        {{-- </center> --}}
                                    </div>
                                </div>

                            </div>


                            {{ Form::close() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
