@extends('backend.layouts.app')
@section('title', 'Beat Calender')

@section('content')

<div class="content-header row">
  <div class="content-header-left col-md-6 col-12 mb-2">
    <h3 class="content-header-title">Beat Calender</h3>
    <div class="row breadcrumbs-top">
      <div class="breadcrumb-wrapper col-12">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{ route('admin.dashboard')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Beat Calender</li>
        </ol>
      </div>
    </div>
  </div>
  <div class="content-header-right col-md-6 col-12 mb-md-0 mb-2">
    <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">
      <div class="btn-group" role="group">
        <a class="btn btn-outline-primary" href="{{ route('admin.beatcalender.create') }}">
          <i class="feather icon-plus"></i> Add
        </a>
      </div>
    </div>
  </div>
</div>


<section id="basic-datatable">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Beat Calender</h4>
                </div>
                <div class="card-content">
                    <div class="card-body card-dashboard">

                        {{--  {{ dd($details->toArray()) }}  --}}
                        <div class="table-responsive">

                            <table class="table zero-configuration" id="tbl-datatable">
                                <thead>
                                    <tr>
                                        <th>Sr. No</th>
                                        <th>Salesman</th>
                                        <th>Sales Executive</th>
                                        <th>Beat</th>
                                        <th>Area</th>
                                        <th>Route</th>
                                        <th>ASE</th>
                                        <th>ASM</th>
                                        <th colspan="3">Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    @if (isset($details) && count($details) > 0)
                                        @php $srno = 1; @endphp
                                        @foreach ($details as $data)
                                            <tr>
                                                <td>{{ $srno }}</td>
                                                <td>{{ $data->salesman }}</td>
                                  
                                                <td><?php
                                                  foreach ($sales_execu_data as $row) {
                                                    if($row->admin_user_id == $data->sales_execu){
                                                      echo $row->full_name;
                                                    }
                                                  }
                                                   ?></td>

                                                <td><?php
                                                  foreach ($beat_data as $row) {
                                                    if($row->beat_id == $data->beat_id){
                                                      echo $row->beat_name;
                                                    }
                                                  }
                                                   ?></td>
                                                <td><?php
                                                foreach ($area_data as $row) {
                                                  if($row->area_id == $data->area_id){
                                                    echo $row->area_name;
                                                  }
                                                }
                                                 ?></td>
                                           
                                           <td><?php
                                            foreach ($route_data as $row) {
                                              if($row->route_id == $data->route_id){
                                                echo $row->route_name;
                                              }
                                            }
                                            
                                             ?></td>
                                                <td>{{ $data->ase }}</td>
                                                <td>{{ $data->asm }}</td>

                                                <td>
                                   
                                                    <a href="{{ url('admin/beatcalender/edit/'.$data->beat_cal_id) }}" class="btn btn-primary" title="Edit"><i class="feather icon-edit"></i></a>
                                       
                                                    {!! Form::open([
                                                        'method'=>'GET',
                                                        'url' => ['admin/beatcalender/delete', $data->beat_cal_id],
                                                        'style' => 'display:inline'
                                                    ]) !!}
                                                        {!! Form::button('<i class="feather icon-trash"></i>', ['type' => 'submit','title'=>'Delete', 'class' => 'btn btn-danger','onclick'=>"return confirm('Are you sure you want to Delete this Entry ?')"]) !!}
                                                    {!! Form::close() !!}

                                                   
                                                </td>
                                            </tr>
                                            @php $srno++; @endphp
                                        @endforeach
                                    @endif
                                </tbody>

                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

@endsection
@section('scripts')
<script src="{{ asset('public/backend-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script src="{{ asset('public/backend-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('public/backend-assets/vendors/js/tables/datatable/dataTables.buttons.min.js') }}"></script>
@endsection
