<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">


<body>

</body>
</html>
