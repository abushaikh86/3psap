@php
use App\Models\backend\Cmspages;
$quick_link_pages = Cmspages::where('column_type','quick_links')->where('cms_pages_footer',1)->where('show_hide',1)->get();
$conntect_us_pages = Cmspages::where('column_type','conntect_us')->where('cms_pages_footer',1)->where('show_hide',1)->get();
$our_policies_pages = Cmspages::where('column_type','our_policies')->where('cms_pages_footer',1)->where('show_hide',1)->get();
@endphp
<!--footer start-->
<footer style="" class="pt-5">
	<div class="container-fluidcustom ">
			<div class="row row-bg  pt-4  pb-4">
				<p>Dadreeios.com is India’s latest, stylish & an amazing online shopping platform which aim to provide best online experience to shoppers across India.Changing in fashion
is very necessary to keep life interesting.</p>
			</div>
		</div>


	<div class="footer-img">
		<img class="img-fluid w-100 " src="{{ asset('public/frontend-assets/images/111.jpg') }}" alt="footer image">

	</div>
	<div class="container-fluidcustom pt-1">
			<div class="row row-bg row-border pt-4">
			<div class="col-lg-12 col-md-12 col-sm-12 col-12 px-0">
				<div class="footer-section">
					<h1>DADREEIOS.COM'S TOP CATEGORIES FOR MEN AND WOMEN</h1>
				</div>
				<div class="pt-4">

								<ul class="navigation-footer nav">
									<span class="footer-category-head">MEN :</span>
											<li class="nav-item">
												<a class=" nav-link active" href="#">Shirts</a>
											</li>
											<li class="nav-item">
											  <a class="nav-link" href="#">T-Shirts</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#">Pants</a>
											</li>
											<li class="nav-item">
												<a class=" nav-link" href="#">Trousers</a>
											</li>
											<li class="nav-item">
												<a class=" nav-link" href="#">Jeans</a>
											</li>
											<li class="nav-item">
											  <a class="nav-link" href="#">Jackets</a>
											</li>
											<li class="nav-item">
												<a class="nav-link " href="#">Night Dresses</a>
											</li>
									</ul>
				</div>

				<div class="pt-3 pb-5">
								<ul class="navigation-footer nav">
									<span class="footer-category-head">WOMEN :</span>
									<li class="nav-item">
										<a class=" nav-link active" href="#">Tops</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#">Jeans</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#">Tunics</a>
									</li>
									<li class="nav-item">
										<a class=" nav-link" href="#">Dresses</a>
									</li>
									<li class="nav-item">
										<a class=" nav-link" href="#">Night Dresses</a>
									</li>
									</ul>
				</div>
			</div>
			</div>
			<div class="row row-bg no-gutters">
				<div class="col-lg-3 pt-2  px-0 col-md-12 col-sm-12 col-12">

					<a href="#"><img class="img-fluid w-100 " src="{{ asset('public/frontend-assets/images/footer-1.jpg') }}" alt=""></a>
				</div>

				<div class="col-lg-2 pt-4 col-md-4 col-sm-4 col-12">
					<div class="footer-header-one">
						<h4>QUICK LINKS</h4>
						@if(isset($quick_link_pages) && count($quick_link_pages)>0)
						<ul class="info-foot pt-3">
							@foreach($quick_link_pages as $quick_link_page)
							<li><a href="{{ url('pages/'.$quick_link_page->cms_slug) }}">{{ $quick_link_page->cms_pages_title }}</a></li>
							@endforeach
						</ul>
						@endif
					</div>
				</div>

				<div class="col-lg-2 pt-4 col-md-4 col-sm-4 col-12">
					<div class="footer-header-two">
						<h4>CONNECT WITH US ON</h4>
						@if(isset($conntect_us_pages) && count($conntect_us_pages)>0)
						<ul class="info-foot pt-3">
							@foreach($conntect_us_pages as $conntect_us_page)
							<li><a href="{{ $conntect_us_page->cms_pages_link }}" target="_blank">{{ $conntect_us_page->cms_pages_title }}</a></li>
							@endforeach
						</ul>
						@endif


					</div>
				</div>
				<div class="col-lg-2 pt-4 col-md-4 col-sm-4 col-12">
					<div class="footer-header-three">
						<h4>OUR POLICIES</h4>

						@if(isset($our_policies_pages) && count($our_policies_pages)>0)
						<ul class="info-foot pt-3">
							@foreach($our_policies_pages as $our_policies_page)
							<li><a href="{{ url('pages/'.$our_policies_page->cms_slug) }}">{{ $our_policies_page->cms_pages_title }}</a></li>
							@endforeach
						</ul>
						@endif
					</div>
				</div>
				<div class="col-lg-3 pt-2  px-0 col-md-12 col-sm-12 col-12">
							<a href="#"><img class="img-fluid w-100" src="{{ asset('public/frontend-assets/images/footer-1.jpg') }}" alt=""></a>
					<div class="footer-sub mt-5">
						<p>Subscribe to Our Newsletter & Get Updates of Our Products, Hot Offers & Amazing Discounts.</p>
					</div>
					<form class="footer-search" action="#">
						<input class="search-in" type="email"  placeholder="Enter Email ID">
							<input class="btn" type="submit" value=" SUBSCRIBE ">
					</form>
				</div>
			</div>

			<div class="row row-bg pt-4 ">
					<div class="col-lg-3 px-0 col-md-12 col-sm-12 col-12 pb-4">
						<a href="#"><img class="img-fluid w-100" src="{{ asset('public/frontend-assets/images/footer-1.jpg') }}" alt=""></a>
					</div>
					<div class="col-lg-7 col-md-12 col-sm-12 col-12 align-self-end justify-content-center  pb-4">
						<section class="mar">
							<div class="footer-header">
								<h4>You can pay securely by following most trusted payment methods</h4>
							</div>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/card_visa.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/card_master.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/Amex.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/card_paypal.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/paytm.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/google-pay.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/bhim.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/Rupay.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/Cashon.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/netbanking.png') }}"/></a>
						</section>
					</div>
					<div class="col-lg-2 col-md-12 col-sm-12 col-12 align-self-end text-center pb-4 p-0">
						<div class="footer-dmca">
							<a href="#">DMCA</a>
						</div>
					</div>
			</div>
		</div>

		<p class="footer-copyright text-center mb-0">© 2021 www.dadreeios.com. All Rights Reserved.</p>

</footer>

<!--  -->

<!--  -->

		<script src="https://code.jquery.com/jquery-3.4.0.min.js" integrity="sha384-JUMjoW8OzDJw4oFpWIB2Bu/c6768ObEthBMVSiIx4ruBIEdyNSUQAjJNFqT5pnJ6" crossorigin="anonymous"></script>
		<script src="{{ asset('public/frontend-assets/js/zoomsl.js') }}"></script>
		<!-- <script src="{{ asset('public/frontend-assets/js/script.js') }}"></script> -->

		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="{{ asset('public/frontend-assets/js/bootstrap.min.js') }}"></script>
		<script src="{{ asset('public/frontend-assets/js/webticker.js') }}"></script>
		<script type="text/javascript" src="{{ asset('public/frontend-assets/js/ticker-note.js') }}"></script>
		<script type="text/javascript" src="{{ asset('public/frontend-assets/js/back-to-top.js') }}"></script>
		<script src="{{ asset('public/frontend-assets/js/mega-menu.js') }}"></script>
		<script src="{{ asset('public/frontend-assets/js/owl.carousel.min.js') }}"></script>
		<script src="{{ asset('public/frontend-assets/js/product-quantity.js') }}"></script>

	<script>
      $(document).ready(function () {
          $(".block__pic").imagezoomsl({
              zoomrange: [3, 3]
          });
          window.stop();
      });
      </script>

      <script>
         function openNav(){
         document.getElementById("collapsibleNavbar-two").style.display = "block";
         }
         function closeNav() {
          document.getElementById("collapsibleNavbar-two").style.display = "none";
         }
      </script>

      <script>
         $('.product-slider1').owlCarousel({
             loop:true,
             margin:10,
             dots:false,
             nav:true,
             mouseDrag:true,
             autoplay:false,
             navSpeed: 1000,
            animateOut: "slideOutDown",
            animateIn: "slideInDown",

             responsive:{
                 0:{
                     items:2,
            slideBy: 2
                 },
                 600:{
                     items:4,
            slideBy: 1
                 },
                 1000:{
                     items:4,
            slideBy: 1
                 }
             }
         });
      </script>
      <!-- Rating -->
      <script>
         const progressDone = document.querySelectorAll('.progress-done');
         progressDone.forEach(progress => {
         progress.style.width = progress.getAttribute('data-done') + '%';
         });
         // SOCIAL PANEL JS
         const floating_btn = document.querySelector('.floating-btn');
         const close_btn = document.querySelector('.close-btn');
         const social_panel_container = document.querySelector('.social-panel-container');
         // floating_btn.addEventListener('click', () => {
         // social_panel_container.classList.toggle('visible')
         // });
         // close_btn.addEventListener('click', () => {
         // social_panel_container.classList.remove('visible')
         // });
      </script>

      <!-- color and size selected  -->
      <script>
         $(document).ready(function(){
           $('.cloth-size').on('click',function()
           {
             $('.cloth-size').removeClass('cloth-size-selected')
             $(this).addClass('cloth-size-selected');
           });
           $('.cloth-color').on('click',function()
           {
             $('.cloth-color').removeClass('cloth-col-selected')
             $(this).addClass('cloth-col-selected');
           });
         });
      </script>

      <!-- View more and less  -->
      <script>
         $(document).ready(function() {
         $("#toggle").click(function() {
           var elem = $("#toggle").text();
           if (elem == "View More Info") {
             //Stuff to do when btn is in the read more state
             $("#toggle").text("View Less Info");
             $("#text").slideDown();
           } else {
             //Stuff to do when btn is in the read less state
             $("#toggle").text("View More Info");
             $("#text").slideUp();
           }
         });
         });
      </script>

      <!-- <script>
      $(document).ready(function() {
  $(".active img").on('click', function() {
    $(this).css({
      "box-shadow": "inset 0 1px 1px #dab6b6, 0 0 8px #da0707"
    });
  });



});
      </script> -->
      <script >
// $(function() {
//      $('.img-hover-shadow').click(function(){
//          // Add "active" to the clicked element and
//          // get all siblings and remove "active" from them
//          $(this).addClass('.unselected').siblings().removeClass('.unselected');
//      });
//
//    });
$(document).ready(function() {
 $('.img-li').click(function (e) {
     e.preventDefault();
     $('.img-li img').removeClass('active1');
     $(this).find('.img-hover-shadow').addClass('active1');

 });
});
</script>
