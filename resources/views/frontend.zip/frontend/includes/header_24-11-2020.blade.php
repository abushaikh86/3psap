@php
use App\Models\frontend\Categories;

$categories = Categories::get();
//echo "<pre>";print_r($categories);exit;
@endphp
<a id="return-to-top" href="javascript:" ><i class="fa fa-chevron-up"></i></a>


<section  id="navbar">
		<section class="top-header">
			<div class="container-fluidcustom">
				<div class="row divider">
					<div class="col-lg-1 dn top-column text-center">
						<a class="m-left " href="#"><i class="fa fa-mobile mr-2" aria-hidden="true"></i>DOWNLOAD APP</a>
					</div>

					<div class="col-lg-1 dn top-column text-center">
						<a href="#"><i class="fa fa-headphones mr-2" aria-hidden="true"></i>CUSTOMER CARE</a>
					</div>

					<div class="col-lg-6 dn top-column text-center">
					<ul  class="ml-5 mr-5" id="webTicker">
						<li class="" > Please note :  Due to covid pandemic products delivery may be affected as well as late
					 </ul>
				</div>

					<div class="col-lg-1 col-3 top-column text-center">
						<a href="#"><i class="fa fa-unlock-alt mr-2" aria-hidden="true"></i><span class="dn">LOGIN</span></a>
					</div>

					<div class="col-lg-1 col-3  top-column text-center">
						<a href="#"><i class="fa fa-user-circle mr-2" aria-hidden="true"></i><span class="dn">YOUR ACCOUNT</span></a>
					</div>

					<div class="col-lg-1 col-3  top-column text-center"><a class="" href="#"><span class="dn">YOUR</span><span class="heart"><i class="fa fa-heart mr-1 ml-1" aria-hidden="true"></i></span><span class="dn">WISHLIST</span></a>
					</div>

					<div class="col-lg-1 col-3 top-column text-center"><a class="cart-link" href="#"><i class="fa fa-cart-plus mr-2" aria-hidden="true"></i><span class="dn">CART</span></a>
					</div>
				</div>
			</div>
		</section>
<!--Topbar End-->

<!--Navigationbar start-->
				  <nav class="navbar navbar-expand-lg navigationbar">
					<div class="col-lg-2 col-md-3 col-sm-4 col-12 left-pad-adj15">
				   <a class="navbar-brand" href="{{ url('/') }}"><img class="img-fluid" src="{{ asset('public/frontend-assets/images/logoparwani.png') }}" alt=""></a>
				   <button class="navbar-toggler text-center" data-toggle="collapse" data-target="#collapsibleNavbar-two">
					<span class="navbar-toggler-icon text-dark"><i class="fa fa-bars" aria-hidden="true"></i></span>
				  </button>
				</div>
				  <div class="collapse navbar-collapse col-lg-6 col-md-5 col-sm-4 col-12 " id="collapsibleNavbar-two">
					 <ul class="navbar-nav" style="margin: auto auto;">
             @if($categories)
             @foreach($categories as $category)
						 @if($category->has_subcategories == '1')
               <li class="nav-item dropdown menu-area sweep-to-bottom">
               <a class="nav-link dropdownbtn dropbtn" href="#" id="menDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 {{ $category->category_name }}
               </a>
               <div class="dropdown-menu mega-area">
                 <div class="row w-100">
                   <div class="col-lg-12">
										 @if(isset($category->subcategories))
										 @foreach($category->subcategories as $subcategory)
                   		<a class="dropdown-item" href="{{ url('s/') }}/{{ $category->category_slug }}/{{ $subcategory->sub_category_slug }}">{{ $subcategory->subcategory_name }}</a>

											@if(isset($subcategory->subsubcategories))
											@foreach($subcategory->subsubcategories as $subsubcategory)
												<!-- {{ $subsubcategory->sub_subcategory_name }} -->
											@endforeach
											@endif
										@endforeach
										@endif
                   </div>
                  </div>
               </div>
               </li>
							@else

							@endif
             @endforeach
             @endif
					  <!-- <li class="nav-item dropdown menu-area sweep-to-bottom">
						<a class="nav-link dropdownbtn dropbtn" href="#" id="menDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  MEN
						</a>
						<div class="dropdown-menu mega-area">
							<div class="row w-100">
							  <div class="col-lg-12">
								<a class="dropdown-item" href="#">Men 1</a>
								<a class="dropdown-item" href="#">Men 2</a>
								<a class="dropdown-item" href="#">Men 3</a>
							  </div>
							 </div>
						</div>
					  </li>

					  <li class="nav-item dropdown sweep-to-bottom">
						<a class="nav-link dropdownbtn dropbtn" href="#" id="womenDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  WOMEN
						</a>
						<div class="dropdown-menu dropdown-content" aria-labelledby="womenDropdown">
							  <div class="column">
								<a class="dropdown-item" href="#">Women 1</a>
								<a class="dropdown-item" href="#">Women 2</a>
								<a class="dropdown-item" href="#">Women 3</a>
							  </div>
						</div>
					  </li>
					  <li class="nav-item dropdown sweep-to-bottom">
						<a class="nav-link dropdownbtn dropbtn" href="#" id="specialDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  <span class="todays-special">TODAY’S SPECIAL DEALS</span>
						</a>
						<div class="dropdown-menu dropdown-content" aria-labelledby="specialDropdown">
							  <div class="column">
								  <a class="dropdown-item" href="#">Deals</a>
								  <a class="dropdown-item" href="#">Deals</a>
								  <a class="dropdown-item" href="#">Deals</a>
							  </div>
						</div>
					  </li>
					  <li class="nav-item dropdown sweep-to-bottom">
						<a class="nav-link dropdownbtn dropbtn" href="#" id="dealsDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  HOT OFFERS
						</a>
						<div class="dropdown-menu dropdown-content" aria-labelledby="dealsDropdown">
							  <div class="column">
								  <a class="dropdown-item" href="#">Offers</a>
								  <a class="dropdown-item" href="#">Offers</a>
								  <a class="dropdown-item" href="#">Offers</a>
							  </div>
						</div>
					  </li>
					  <li class="nav-item dropdown sweep-to-bottom">
						<a class="nav-link dropdownbtn dropbtn" href="#" id="cartDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  MORE
						</a>
						<div class="dropdown-menu dropdown-content" aria-labelledby="cartDropdown">
							  <div class="column">
								  <a class="dropdown-item" href="#">More</a>
								  <a class="dropdown-item" href="#">More</a>
								  <a class="dropdown-item" href="#">More</a>
							  </div>
						</div>
					  </li> -->
					</ul>
				  </div>
					<div class="col-lg-4 col-md-4 col-sm-3 col-12 right-pad-adj15">
						<form class="input-group">
							<input class="search" type="text" placeholder="Search For Products, Categories & More.." aria-label="Search">
							<i class="fa fa-search" aria-hidden="true"></i>
						</form>
					</div>
				</nav>
</section>
<!--Navigationbar end-->
