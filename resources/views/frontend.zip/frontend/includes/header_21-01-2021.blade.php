@php
use App\Models\frontend\Categories;

$categories = Categories::get();
//echo "<pre>";print_r($categories);exit;
@endphp
<a id="return-to-top" href="javascript:" ><i class="fa fa-chevron-up"></i></a>


<section  id="navbar">
		<section class="top-header">
			<div class="container-fluidcustom">
				<div class="row divider">
					<div class="col-lg-1 dn top-column text-center">
						<a class="m-left " href="#"><i class="fa fa-mobile mr-2" aria-hidden="true"></i>DOWNLOAD APP</a>
					</div>

					<div class="col-lg-1 dn top-column text-center">
						<a href="#"><i class="fa fa-headphones mr-2" aria-hidden="true"></i>CUSTOMER CARE</a>
					</div>

					<div class="col-lg-6 dn top-column text-center">
					<ul  class="ml-5 mr-5" id="webTicker">
						<li class="" > Please note :  Due to covid pandemic products delivery may be affected as well as late
					 </ul>
				</div>

					<div class="col-lg-1 col-3 top-column text-center">
						<a href="#"><i class="fa fa-unlock-alt mr-2" aria-hidden="true"></i><span class="dn">LOGIN</span></a>
					</div>

					<div class="col-lg-1 col-3  top-column text-center">
						<a href="#"><i class="fa fa-user-circle mr-2" aria-hidden="true"></i><span class="dn">YOUR ACCOUNT</span></a>
					</div>

					<div class="col-lg-1 col-3  top-column text-center"><a class="" href="#"><span class="dn">YOUR</span><span class="heart"><i class="fa fa-heart mr-1 ml-1" aria-hidden="true"></i></span><span class="dn">WISHLIST</span></a>
					</div>

					<div class="col-lg-1 col-3 top-column text-center"><a class="cart-link" href="#"><i class="fa fa-cart-plus mr-2" aria-hidden="true"></i><span class="dn">CART</span></a>
					</div>
				</div>
			</div>
		</section>
<!--Topbar End-->

<!--Navigationbar start-->
<nav id="navigation1" class="navigation navbar navbar-expand-lg ">
			<div class="row navigationbar mx-0">
			<div class="col-lg-2 col-md-3 col-sm-4 col-12 left-pad-adj15">
			 <a class="navbar-brand" href="{{ url('/') }}"><img class="img-fluid" src="{{ asset('public/frontend-assets/images/logoparwani.png') }}" alt=""></a>
			 <button class="navbar-toggler text-center" onclick="openNav()" data-toggle="collapse" data-target="#collapsibleNavbar-two">
			<span class="navbar-toggler-icon text-dark"><i class="fa fa-bars" aria-hidden="true"></i></span>
			</button>
		</div>

			<div class="nav-menus-wrapper collapse navbar-collapse col-lg-6 col-md-5 col-sm-4 col-12 " id="collapsibleNavbar-two">
				<button class="close-menu-btn" onclick="closeNav()" >&#10005;</button>
				<ul class="nav-menu m-auto ">
					@if($categories)
					@foreach($categories as $category)
					@if($category->has_subcategories == '1')
					<li>
						<a class="sweep-to-bottom"  href="#">{{ $category->category_name }}</a>
						@if(isset($category->subcategories))
						<div class="megamenu-panel">
							<div class="megamenu-lists">
									@foreach($category->subcategories as $subcategory)
									<ul class="megamenu-list list-col-4">
										<li class="megamenu-list-title"><a href="#">{{ $subcategory->subcategory_name }}</a></li>
											@if(isset($subcategory->subsubcategories))
											@foreach($subcategory->subsubcategories as $subsubcategory)
												<li><a href="{{ url('s/') }}/{{ $category->category_slug }}/{{ $subcategory->sub_category_slug }}/{{ $subsubcategory->sub_sub_category_slug }}" target="_blank">{{ $subsubcategory->sub_subcategory_name }}</a></li>
											@endforeach
											@endif
										</ul>
									@endforeach
							</div>
						</div>
						@endif
					</li>
					@else

					@endif
				 @endforeach
				 @endif
					<!-- <li>
						<a class="sweep-to-bottom"  href="#">WOMEN</a>
						<div class="megamenu-panel">
							<div class="megamenu-lists">
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
								</ul>
							</div>
						</div>
					</li>i>
					<li>
					 <a  class="sweep-to-bottom" href="#"><span class="todays-special">TODAY’S SPECIAL DEALS</span></a>
					 <div class="megamenu-panel">
						 <div class="megamenu-lists">
							 <ul class="megamenu-list list-col-4">
								 <li class="megamenu-list-title"><a href="#">Tops</a></li>
								 <li><a href="#" target="_blank">Tops</a></li>
								 <li><a href="#" target="_blank">Tops</a></li>
								 <li><a href="#" target="_blank">Tops</a></li>
								 <li><a href="#" target="_blank">Tops</a></li>
								 <li><a href="#" target="_blank">Tops</a></li>
							 </ul>
							 <ul class="megamenu-list list-col-4">
								 <li class="megamenu-list-title"><a href="#">Jeans</a></li>
								 <li><a href="#" target="_blank">Jeans</a></li>
								 <li><a href="#" target="_blank">Jeans</a></li>
								 <li><a href="#" target="_blank">Jeans</a></li>
								 <li><a href="#" target="_blank">Jeans</a></li>
								 <li><a href="#" target="_blank">Jeans</a></li>
							 </ul>
							 <ul class="megamenu-list list-col-4">
								 <li class="megamenu-list-title"><a href="#">Tunics</a></li>
								 <li><a href="#" target="_blank">Tunics</a></li>
								 <li><a href="#" target="_blank">Tunics</a></li>
								 <li><a href="#" target="_blank">Tunics</a></li>
								 <li><a href="#" target="_blank">Tunics</a></li>
								 <li><a href="#" target="_blank">Tunics</a></li>
							 </ul>
							 <ul class="megamenu-list list-col-4">
								 <li class="megamenu-list-title"><a href="#">Dress</a></li>
								 <li><a href="#" target="_blank">Dress</a></li>
								 <li><a href="#" target="_blank">Dress</a></li>
								 <li><a href="#" target="_blank">Dress</a></li>
								 <li><a href="#" target="_blank">Dress</a></li>
								 <li><a href="#" target="_blank">Dress</a></li>
							 </ul>
						 </div>
					 </div>
				 </li>
					<li>
						<a class="sweep-to-bottom"  href="#">HOT OFFERS</a>
						<div class="megamenu-panel">
							<div class="megamenu-lists">
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
									<li><a href="#" target="_blank">Tops</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
									<li><a href="#" target="_blank">Tunics</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
									<li><a href="#" target="_blank">Dress</a></li>
								</ul>
							</div>
						</div>
					</li>
					<li>
						<a class="sweep-to-bottom"  href="#">MORE</a>
						<div class="megamenu-panel">
							<div class="megamenu-lists">
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Shirts</a></li>
									<li><a href="#" target="_blank">Shirts</a></li>
									<li><a href="#" target="_blank">Shirts</a></li>
									<li><a href="#" target="_blank">Shirts</a></li>
									<li><a href="#" target="_blank">Shirts</a></li>
									<li><a href="#" target="_blank">Shirts</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">T-Shirts</a></li>
									<li><a href="#" target="_blank">T-Shirts</a></li>
									<li><a href="#" target="_blank">T-Shirts</a></li>
									<li><a href="#" target="_blank">T-Shirts</a></li>
									<li><a href="#" target="_blank">T-Shirts</a></li>
									<li><a href="#" target="_blank">T-Shirts</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
									<li><a href="#" target="_blank">Jeans</a></li>
								</ul>
								<ul class="megamenu-list list-col-4">
									<li class="megamenu-list-title"><a href="#">Jackets</a></li>
									<li><a href="#" target="_blank">Jackets</a></li>
									<li><a href="#" target="_blank">Jackets</a></li>
									<li><a href="#" target="_blank">Jackets</a></li>
									<li><a href="#" target="_blank">Jackets</a></li>
									<li><a href="#" target="_blank">Jackets</a></li>
								</ul>
							</div>
						</div>
					</li> -->
				</ul>
			</div>

				<div class="col-lg-4 col-md-4 col-sm-3 col-12 right-pad-adj15 my-auto">
					<form class="input-group">
						<input class="search" type="text" placeholder="Search For Products, Categories & More.." aria-label="Search">
						<i class="fa fa-search" aria-hidden="true"></i>
					</form>
				</div>
</div>
		</nav>
</section>
<!--Navigationbar end-->
