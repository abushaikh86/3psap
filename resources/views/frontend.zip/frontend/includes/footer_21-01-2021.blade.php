<!--footer start-->
<footer style="" class="pt-5">
	<div class="container-fluidcustom ">
			<div class="row row-bg  pt-4">
				<h5 class="footer-h5">Dadreeios.com is India’s latest, stylish & an amazing online shopping platform which aim to provide best online experience to shoppers across India.
					Changing in fashion is very necessary to keep life interesting.</h5>
			</div>
		</div>


	<div class="footer-img">
		<img class="img-fluid w-100 " src="{{ asset('public/frontend-assets/images/111.jpg') }}" alt="footer image">

	</div>
	<div class="container-fluidcustom pt-5">
			<div class="row row-bg row-border pt-4">
			<div class="col-lg-12 col-md-12 col-sm-12 col-12 px-0">
				<div class="footer-section">
					<h1>DADREEIOS.COM'S TOP CATEGORIES FOR MEN AND WOMEN.</h1>
				</div>
				<div class="pt-4">

								<ul class="navigation-footer nav">
									<span class="footer-category-head">MEN :</span>
											<li class="nav-item">
												<a class=" nav-link active" href="#">Shirts</a>
											</li>
											<li class="nav-item">
											  <a class="nav-link" href="#">T-Shirts</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#">Pants</a>
											</li>
											<li class="nav-item">
												<a class=" nav-link" href="#">Trousers</a>
											</li>
											<li class="nav-item">
												<a class=" nav-link" href="#">Jeans</a>
											</li>
											<li class="nav-item">
											  <a class="nav-link" href="#">Jackets</a>
											</li>
											<li class="nav-item">
												<a class="nav-link " href="#">Night Dresses</a>
											</li>
									</ul>
				</div>

				<div class="pt-3 pb-5">
								<ul class="navigation-footer nav">
									<span class="footer-category-head">WOMEN :</span>
									<li class="nav-item">
										<a class=" nav-link active" href="#">Tops</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#">Jeans</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#">Tunics</a>
									</li>
									<li class="nav-item">
										<a class=" nav-link" href="#">Dresses</a>
									</li>
									<li class="nav-item">
										<a class=" nav-link" href="#">Night Dresses</a>
									</li>
									</ul>
				</div>
			</div>
			</div>
			<div class="row row-bg no-gutters">
				<div class="col-lg-3 pt-2  px-0 col-md-3 col-sm-3 col-12">

					<a href="#"><img class="img-fluid w-100 " src="{{ asset('public/frontend-assets/images/footer-1.jpg') }}" alt=""></a>
				</div>

				<div class="col-lg-2 pt-4 col-md-2 col-sm-2 col-12">
					<div class="footer-header-one">
						<h4>QUICK LINKS</h4>
						<ul class="info-foot pt-3">
							<li><a href="#">About Us</a></li>
							<li><a href="#">Contact Us</a></li>
							<li><a href="#">FAQ</a></li>
							<li><a href="#">Careers</a></li>
						</ul>

					</div>
				</div>

				<div class="col-lg-2 pt-4 col-md-2 col-sm-2 col-12">
					<div class="footer-header-two">
						<h4>CONNECT WITH US ON</h4>

							<ul class="info-foot pt-3">
							<li><a href="#">Facebook</a></li>
							<li><a href="#">Instagram</a></li>
							<li><a href="#">Twitter</a></li>
							<li><a href="#">You Tube</a></li>
							<li><a href="#">Pinterest</a></li>
							<li><a href="#">Linked In</a></li>
							<li><a href="#">Google My Business</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">WhatsApp</a></li>
						</ul>


					</div>
				</div>
				<div class="col-lg-2 pt-4 col-md-2 col-sm-2 col-12">
					<div class="footer-header-three">
						<h4>OUR POLICIES</h4>
						<ul class="info-foot pt-3">
							<li><a href="#">Terms & Conditions</a></li>
							<li><a href="#">Security Policy</a></li>
							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Shipping Policy</a></li>
							<li><a href="#">Return & Refund Policy</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 pt-2  px-0 col-md-3 col-sm-3 col-12">
							<a href="#"><img class="img-fluid w-100" src="{{ asset('public/frontend-assets/images/footer-1.jpg') }}" alt=""></a>
					<div class="footer-sub mt-5">
						<p>Subscribe to Our Newsletter & Get Updates of Our Products, Hot Offers & Amazing Discounts.</p>
					</div>
					<form class="footer-search" action="#">
						<input type="email"  placeholder="ENTER YOUR EMAIL ID">
							<input class="btn" type="submit" value=" SUBSCRIBE ">
					</form>
				</div>
			</div>

			<div class="row row-bg pt-4 ">
					<div class="col-lg-3 px-0 col-md-3 col-sm-3 col-12 pb-4">
						<a href="#"><img class="img-fluid w-100" src="{{ asset('public/frontend-assets/images/footer-1.jpg') }}" alt=""></a>
					</div>
					<div class="col-lg-7 col-md-6 col-sm-6 col-12 align-self-end justify-content-center  pb-4">
						<section class="mar">
							<div class="footer-header">
								<h4>You can pay securely by following most trusted payment methods</h4>
							</div>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/card_visa.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/card_master.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/card_paypal.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/google-pay.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/amazon.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/bhim.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/square.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/whtssp.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/paytm.png') }}"/></a>
									<a  href="#"><img height="40" class="pay-img img-fluid" src="{{ asset('public/frontend-assets/images/payment/PhonePe.png') }}"/></a>
						</section>


					</div>
					<div class="col-lg-2 col-md-3 col-sm-3 col-12 align-self-end text-center pb-4 p-0">

						<div class="footer-dmca">
							<a href="#">DMCA</a>
						</div>
					</div>
			</div>
		</div>

		<p class="footer-copyright text-center mb-0">© 2021 www.dadreeios.com. All Rights Reserved.</p>

</footer>




<!--footer end-->

<!--  -->

<!--  -->
	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script> -->
	<!-- <script src="assets/js/bootstrap.min.js"></script> -->
	<!-- <script src="assets/js/owl.carousel.min.js"></script> -->
	<!-- <script src="assets/js/jquery.jConveyorTicker.min.js"></script> -->
	<!-- <script src="assets/js/webticker.js"></script> -->
	<script type="text/javascript">

				$('#webTicker').webTicker();
			</script>		<script >
				$(window).scroll(function(){
				  if ($(window).scrollTop() >=100) {
					  $('#navbar').addClass('fixed-header');
				  }
				  else {
					  $('#navbar').removeClass('fixed-header');
				  }
				});
			</script>

			<script>
				// ===== Scroll to Top ====
				$(window).scroll(function() {
					if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
							$('#return-to-top').fadeIn(200);    // Fade in the arrow
					} else {
							$('#return-to-top').fadeOut(200);   // Else fade out the arrow
					}
				});
				$('#return-to-top').click(function() {      // When arrow is clicked
					$('body,html').animate({
							scrollTop : 0                       // Scroll to top of body
					}, 4000);
				});
			</script>
			<!-- product slider 15 images-->
			<script>
	         $('.product-slider').owlCarousel({
	             loop:true,
	             margin:10,
	             dots:false,
	             nav:true,
	             mouseDrag:true,
	             autoplay:true,
							 navSpeed: 1000,
	      			animateOut: "slideOutDown",
	      			animateIn: "slideInDown",

	             responsive:{
	                 0:{
	                     items:2,
						  slideBy: 2
	                 },
	                 600:{
	                     items:5,
						  slideBy: 1
	                 },
	                 1000:{

	                     items:5,
						  slideBy: 1
	                 }
	             }

	         });

	      </script>
	<!-- product slider 15 images end-->





	<script>
	function openNav(){
		document.getElementById("collapsibleNavbar-two").style.display = "block";

	}
	function closeNav() {
	  document.getElementById("collapsibleNavbar-two").style.display = "none";
	}
	</script>
